﻿using InventoryMgmt_Backend.Models;

namespace InventoryMgmt_Backend.Dtos
{
    public class PlaceOrderDto
    {
        public Address Address { get; set; }
        public Payment Payment { get; set; }
        public string CustomerId { get; set; }
        public List<Product> Cart { get; set; }
    }
}
