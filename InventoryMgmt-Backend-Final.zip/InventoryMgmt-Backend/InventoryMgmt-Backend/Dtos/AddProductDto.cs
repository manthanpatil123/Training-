﻿namespace InventoryMgmt_Backend.Dtos
{
    public class AddProductDto
    {
        public int Prodid { get; set; }
        public string Pname { get; set; }
        public int? Pcat { get; set; }
        public int Qty { get; set; }
        public decimal? Price { get; set; }
        public string Sellerid { get; set; }
        public IFormFile Pic { get; set; }
    }
}
