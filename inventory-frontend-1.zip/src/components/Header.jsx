import axios from "axios";
import { useContext, useState } from "react";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { GlobalInfo } from "../App";
import { BASE_URL } from "../constants/constants";

function Header() {
  const state = useSelector((state) => state);
  const [cat, setcat] = useState(0);
  const [search, setsearch] = useState("");
  const navigate = useNavigate();
  const { cats, setcats } = useContext(GlobalInfo);

  useEffect(() => {
    axios.get(BASE_URL + "api/category").then((resp) => setcats(resp.data));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/", { state: { cat, search } });
  };

  return (
    <div className="jumbotron p-3 mb-0 rounded-0 header">
      <img
        src={"/shop.jpg"}
        style={{ width: "100px" }}
        alt="Logo"
        className="float-left"
      />
      {state.loggedin.IsLoggedIn ? (
        <>
          <h5 className="float-right">Welcome! {state.loggedin.Username}</h5>{" "}
        </>
      ) : (
        ""
      )}
      <div className="search-bar-top">
      <h3>Welcome to Inventory Management</h3> 
      </div>      
      <div className="clearfix"></div>
    </div>
  );
}

export default Header;
