import { useContext, useEffect, useState } from "react";
import axios from "axios";
import { GlobalInfo } from "../App";
import { BASE_URL } from "../constants/constants";

function Categories(){
    const [data,setdata]=useState([])
    const [catid,setcatid]=useState(0)
    const [catname,setcatname]=useState('')
    const {setcats}=useContext(GlobalInfo)

    useEffect(()=>{
        loadData()
    },[])

    const loadData=()=>{
        axios.get(BASE_URL+"api/category").then(resp=>{
            setcats(resp.data)
            setdata(resp.data)
        })
    }

    const handleSubmit= e=>{
        e.preventDefault()
        if(catname===undefined){
            alert('Name is required')
            return
        }
        axios.post(BASE_URL+'api/category',
        {catid,catname}
        )
        .then(resp=>{
            loadData()
            setcatname('')
            setcatid(null)
            alert("category added")
        })
    }

    const editcategory=x=>{
        setcatid(x.catid)
        setcatname(x.catname)
    }

    const deleteCategory = (catid)=>{
        let resp=window.confirm('Are you sure to delete this category ?');
        if(resp){
            axios.delete(BASE_URL+'api/category/'+catid)
            .then(resp=>{
                loadData()
            })
        }
    }
    
    return (
        <div className="container">
            <div className="card shadow">
                <div className="card-body">                    
            <h4 className="p-2">Categories</h4>
            <div className="row">
                <div className="col-sm-8">
                <table className="table table-bordered">
                <thead className="table-light">
                    <tr>
                        <th>Id</th>
                        <th>Category</th>
                        <th>Action</th>                                
                    </tr>
                </thead>
                <tbody>
                {data.map(x=>(
                    <tr key={x.catid}>
                        <td>{x.catid}</td>
                        <td>{x.catname}</td>
                        <td>
                            <button onClick={e=>editcategory(x)} className="btn btn-primary btn-sm mr-2">Edit</button>
                            <button onClick={()=>deleteCategory(x.catid)} className="btn btn-danger btn-sm">Delete</button>
                        </td>                                
                    </tr>
                ))}
                </tbody>
            </table>
                </div>
                <div className="col-sm-4">
                    <h4 className="p-2">Add Category</h4>
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label>Category Name</label>
                            <input type="text" name="catname" value={catname} onChange={e=>setcatname(e.target.value)} className="form-control" />
                        </div>
                        <button type="submit" className="btn btn-primary">Save Category</button>
                    </form>
                </div>
            </div>
            
        </div>
        
        </div>
            </div>
    )
}

export default Categories;