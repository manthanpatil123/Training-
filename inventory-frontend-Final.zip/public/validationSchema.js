import * as yup from 'yup';

const USER_ID_REGEX = /^[a-zA-Z](?=.*\d)[a-zA-Z\d._]{5,14}$/;
const PHONE_REGEX = /^\d{10}$/;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

export const validationSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .min(3, "Name must be at least 3 characters long")
    .required("Name is required"),
  
  city: yup
    .string()
    .trim()
    .required("City is required"),
  
  userid: yup
    .string()
    .trim()
    .matches(USER_ID_REGEX, "User ID must be 6-15 characters long, start with a letter, and include at least one letter and one digit. Periods and underscores are optional but cannot be consecutive.")
    .test('start-end', 'User ID cannot start or end with a period or underscore', value => !/^[._]|[._]$/.test(value))
    .test('consecutive', 'User ID cannot have consecutive periods or underscores', value => !/([._])\1/.test(value))
    .test('contains-both', 'User ID cannot contain both underscores and periods', value => !(value.includes('_') && value.includes('.')))
    .required("User ID is required"),
  
  phone: yup
    .string()
    .matches(PHONE_REGEX, "Phone number must be exactly 10 digits long")
    .required("Phone number is required"),
  
  gender: yup
    .string()
    .required("Gender is required"),
  
  pwd: yup
    .string()
    .matches(PASSWORD_REGEX, "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character (e.g., @$!%*?&)")
    .required("Password is required"),
  
  cpwd: yup
    .string()
    .oneOf([yup.ref('pwd')], "Passwords must match")
    .required("Confirm Password is required"),
});
