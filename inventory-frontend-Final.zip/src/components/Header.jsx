import axios from "axios";
import { useContext, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { GlobalInfo } from "../App";
import { BASE_URL } from "../constants/constants";

function Header() {
  const state = useSelector((state) => state);
  const [cat, setcat] = useState(0);
  const [search, setsearch] = useState("");
  const navigate = useNavigate();
  const { cats, setcats } = useContext(GlobalInfo);

  useEffect(() => {
    axios.get(BASE_URL + "api/category").then((resp) => setcats(resp.data));
  }, [setcats]);

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/", { state: { cat, search } });
  };

  return (
    <div className="header">
      <div className="header-content">
        <div className="message-container">
          {!state.loggedin.IsLoggedIn ? (
            <h6 className="guest-welcome-message">Welcome to InventoryHub!</h6>
          ) : (
            <h6 className="user-welcome-message">
              Welcome! {state.loggedin.Username}
            </h6>
          )}
        </div>
      </div>
    </div>
  );
}

export default Header;
