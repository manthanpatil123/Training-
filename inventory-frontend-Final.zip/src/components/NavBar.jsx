import { useSelector } from "react-redux";
import { Link, NavLink } from "react-router-dom";
import RoleNavbar from "./RoleNavbar";
import { useContext, useEffect } from "react";
import axios from "axios";
import { GlobalInfo } from "../App";
import { BASE_URL } from "../constants/constants";


function NavBar() {
  const state = useSelector((state) => state);
  const { cats, setcats } = useContext(GlobalInfo);
  const isLoggedIn = state.loggedin.IsLoggedIn;

  useEffect(() => {
    axios
      .get(BASE_URL + "api/category")
      .then((resp) => setcats(resp.data))
      .catch(() => setcats([]));
  }, [setcats]);

  return (
    <>
      <div className="clearfix"></div>
      <nav className="navbar navbar-expand-lg navbar-light">
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNavDropdown">
          <ul className="navbar-nav">
            {/* Logo */}
            <li className="nav-item active">
              <NavLink className="nav-link" to="/">
                <img
                  src="minilogo.png"
                  alt="InventoryHub Logo"
                  className="nav-logo"
                />
              </NavLink>
            </li>

            {/* Home Link with Icon */}
            <li className="nav-item active">
              <NavLink className="nav-link" to="/home">
                <i className="fas fa-home"></i> Home
              </NavLink>
            </li>

            {/* Categories Dropdown with Icon */}
            <li className="nav-item dropdown">
              <Link
                className="nav-link dropdown-toggle"
                to="#"
                id="navbarDropdownMenuLink"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                <i className="fas fa-th-large"></i> Categories
              </Link>
              <div
                className="dropdown-menu"
                aria-labelledby="navbarDropdownMenuLink"
              >
                {cats &&
                  cats.map((x) => (
                    <Link
                      key={x.catid}
                      className="dropdown-item"
                      to={"/cats/" + x.catid}
                    >
                      {x.catname}
                    </Link>
                  ))}
              </div>
            </li>
          </ul>

          {/* Conditional Rendering for Login / Logout */}
          {isLoggedIn ? (
            <RoleNavbar isLoggedIn={isLoggedIn} />
          ) : (
            <ul className="navbar-nav ml-auto">
              <li className="navbar-item">
                <NavLink className="loginnavbar-link" to="/login">
                  <i className="fas fa-sign-in-alt"></i> Login
                </NavLink>
              </li>
            </ul>
          )}
        </div>
      </nav>
    </>
  );
}

export default NavBar;
