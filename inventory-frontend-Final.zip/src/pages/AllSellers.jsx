import axios from "axios";
import { useEffect, useState } from "react";
import { BASE_URL } from "../constants/constants";

function AllSellers() {
  const [sellers, setSellers] = useState([]);
  useEffect(() => {
    axios.get(BASE_URL + "api/users/byrole?role=Seller").then((resp) => {
      //console.log(resp.data.data)
      setSellers(resp.data);
      console.log(sellers);
    });
  }, []);

  const deleteSeller = (id) => {
    let response = window.confirm("Are you sure to delete this seller ?");
    if (response) {
      console.log(id);
      axios.delete(BASE_URL + "api/sellers/" + id).then((resp) => {
        axios.get(BASE_URL + "api/sellers").then((resp) => {
          //console.log(resp.data.data)
          setSellers(resp.data);
        });
      });
    }
  };

  return (
    <div className="container-fluid">
      <h4 className="p-2 text-center">All Sellers</h4>
      <table className="table table-bordered table-striped table-light table-hover">
        <thead className="table-dark">
          <tr>
            <th>User Id</th>
            <th>Name</th>
            <th>City</th>
            <th>Phone</th>
          
          </tr>
        </thead>
        <tbody>
          {sellers.map((x) => (
            <tr key={x.userid}>
              <td>{x.userid}</td>
              <td>{x.name}</td>
              <td>{x.city}</td>
              <td>{x.phone}</td>
             
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AllSellers;
