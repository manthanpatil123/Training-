import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import productvalidation from "../validations/productvalidation";
import { BASE_URL } from "../constants/constants";
import "../CSS/AddProduct.css"; // Updated custom CSS for Add Product

function AddProduct() {
  const sellerid = localStorage.getItem("userid");

  const [product, setProduct] = useState({
    pname: "",
    pcat: "",
    price: "",
    descr: "",
    qty: 1,
    sellerId: sellerid,
    photo: null,
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [isFileValid, setIsFileValid] = useState(true); // Track file validity
  const [fileSizeError, setFileSizeError] = useState(""); // Track file size error
  const [fileTypeError, setFileTypeError] = useState(""); // Track file type error
  const navigate = useNavigate();
  const [cats, setCats] = useState([]);

  useEffect(() => {
    axios.get(BASE_URL + "api/category").then((resp) => setCats(resp.data));
  }, []);

  const handleInput = (e) => {
    const { name, value } = e.target;
    setProduct((prev) => ({ ...prev, [name]: value }));

    const validationErrors = productvalidation({ ...product, [name]: value });
    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      if (!validationErrors[name]) {
        delete updatedErrors[name];
      }
      return updatedErrors;
    });
  };

  const handleFileInput = (e) => {
    const file = e.target.files[0];

    if (file) {
      // Check for file type
      if (!["image/jpeg", "image/png", "image/jpg"].includes(file.type)) {
        setFileTypeError("Only JPG, JPEG, and PNG files are allowed.");
        setIsFileValid(false);
        setErrors((prevErrors) => ({
          ...prevErrors,
          photo: "Only JPG, JPEG, and PNG files are allowed.",
        }));
        return;
      }

      // Check for file size
      if (file.size > 2 * 1024 * 1024) {
        // 2 MB limit
        setFileSizeError("File size exceeds 2 MB.");
        setIsFileValid(false);
        setErrors((prevErrors) => ({
          ...prevErrors,
          photo: "File size exceeds 2 MB",
        }));
        return;
      }

      setSelectedPhoto(file);
      setProduct((prev) => ({ ...prev, photo: file }));
      setIsFileValid(true); // File is valid
      setFileSizeError(""); // Clear file size error
      setFileTypeError(""); // Clear file type error
      setErrors((prevErrors) => {
        const updatedErrors = { ...prevErrors };
        delete updatedErrors.photo; // Clear previous photo errors if file is valid
        return updatedErrors;
      });
    } else {
      setIsFileValid(false);
      setFileSizeError(""); // Clear file size error
      setFileTypeError(""); // Clear file type error
      setErrors((prevErrors) => ({
        ...prevErrors,
        photo: "Image is required",
      }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const trimmedValue = value.trim().replace(/\s+/g, " ");

    setProduct((prev) => ({ ...prev, [name]: trimmedValue }));
    setTouched((prev) => ({ ...prev, [name]: true }));

    const validationError = productvalidation({
      ...product,
      [name]: trimmedValue,
    });
    setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const allFieldsTouched = {
      pname: true,
      pcat: true,
      price: true,
      qty: true,
      photo: true, // Ensure photo field is marked as touched
    };
    setTouched(allFieldsTouched);

    const validationErrors = productvalidation(product);
    setErrors(validationErrors);

    // Check if file is valid and ensure validation errors are included
    if (Object.keys(validationErrors).length === 0 && isFileValid) {
      setSubmitted(true);
    } else {
      setSubmitted(false);
      alert(
        "Please ensure all fields are filled correctly."
      );
    }
  };

  useEffect(() => {
    if (Object.keys(errors).length === 0 && submitted) {
      const formData = new FormData();
      formData.append("pic", selectedPhoto);
      formData.append("pname", product.pname);
      formData.append("price", product.price);
      formData.append("qty", product.qty);
      formData.append("pcat", product.pcat);
      formData.append("sellerId", sellerid);

      axios
        .post(BASE_URL + "api/products", formData)
        .then((resp) => {
          alert("Product saved successfully");
          navigate("/myproducts");
        })
        .catch((error) => {
          console.log("Error", error);
          alert("Error saving product");
        });
    }
  }, [
    errors,
    navigate,
    product.pcat,
    product.pname,
    product.price,
    product.qty,
    selectedPhoto,
    sellerid,
    submitted,
  ]);

  return (
    <div className="add-product-container">
      <div className="add-product-card">
        <div className="add-product-image">
          {/* Add any additional image styling or content here if needed */}
        </div>
        <div className="add-product-form">
          <h4 className="add-product-title">Add New Product</h4>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="pname">
                Product Name<span className="required">*</span>
              </label>
              <input
                type="text"
                id="pname"
                name="pname"
                value={product.pname}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.pname && errors.pname ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="addpro-error-container">
                {touched.pname && errors.pname && (
                  <small className="text-danger">{errors.pname}</small>
                )}
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="pcat">
                Category<span className="required">*</span>
              </label>
              <select
                id="pcat"
                name="pcat"
                value={product.pcat}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.pcat && errors.pcat ? "is-invalid" : ""
                }`}
              >
                <option value="">Select Category</option>
                {cats.map((x) => (
                  <option key={x.catid} value={x.catid}>
                    {x.catname}
                  </option>
                ))}
              </select>{" "}
              <div className="addpro-error-container">
                <div className="addpro-">
                  {touched.pcat && errors.pcat && (
                    <small className="text-danger">{errors.pcat}</small>
                  )}
                </div>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="price">
                Price<span className="required">*</span>
              </label>
              <input
                type="number"
                id="price"
                name="price"
                value={product.price}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.price && errors.price ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="addpro-error-container">
                <div className="addpro-">
                  {touched.price && errors.price && (
                    <small className="text-danger">{errors.price}</small>
                  )}
                </div>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="photo">
                Quantity<span className="required">*</span>
              </label>
              <input
                type="number"
                name="qty"
                min={1}
                value={product.qty}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.qty && !product.qty ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="addpro-error-container">
                <div className="addpro-">
                  {touched.qty && errors.qty && (
                    <small className="text-danger float-left">
                      {errors.qty}
                    </small>
                  )}
                </div>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="photo">
                Product Image<span className="required">*</span>
              </label>
              <input
                type="file"
                name="photo"
                accept="image/*"
                onChange={handleFileInput}
                onBlur={() => setTouched((prev) => ({ ...prev, photo: true }))}
                className={`form-control ${
                  touched.photo &&
                  (errors.photo || fileSizeError || fileTypeError)
                    ? "is-invalid"
                    : ""
                }`}
              />
              <div className="addpro-error-container">
                {touched.photo &&
                  (errors.photo || fileSizeError || fileTypeError) && (
                    <small className="text-danger float-left">
                      {errors.photo || fileSizeError || fileTypeError}
                    </small>
                  )}
              </div>
            </div>

            <button
              type="submit"
              className="addpro-btn"
              disabled={Object.keys(errors).length > 0}
            >
              Add Product
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default AddProduct;
