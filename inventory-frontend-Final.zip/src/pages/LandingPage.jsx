import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/LandingPage.css"; // Ensure you have styles for the welcome message

function LandingPage() {
  const [isZoomed, setIsZoomed] = useState(false);
  const [isMessageVisible, setIsMessageVisible] = useState(true);
  const [displayedText, setDisplayedText] = useState(""); // Text being displayed with typing effect
  const [isCursorVisible, setIsCursorVisible] = useState(true); // Controls cursor visibility for blinking effect
  const navigate = useNavigate();
  
  const fullText = "Welcome to InventoryHub!"; // Original welcome message

  const handleClick = () => {
    setIsMessageVisible(false); // Hide the welcome message with CSS transition
    setIsZoomed(true);          // Start zoom effect
    setTimeout(() => {
      navigate("/home");        // Navigate to the home page after the zoom effect
    }, 1000);                   // Match timeout to transition duration (1 second)
  };

  // Typing effect with blinking cursor
  useEffect(() => {
    let currentIndex = 0; // Start from the beginning of the text
    const typingSpeed = 100; // Speed of typing (in milliseconds)

    const typeNextLetter = () => {
      if (currentIndex < fullText.length) {
        setDisplayedText(fullText.slice(0, currentIndex + 1)); // Show text from start to current index
        currentIndex++;
        setTimeout(typeNextLetter, typingSpeed);
      } else {
        // Once typing is complete, start the blinking cursor
        setIsCursorVisible(true);
      }
    };

    const delayBeforeTyping = 500; // Delay before starting typing
    setTimeout(typeNextLetter, delayBeforeTyping); // Start typing

  }, [fullText]);

  // Blinking cursor effect
  useEffect(() => {
    if (isCursorVisible) {
      const cursorBlinkSpeed = 500; // Speed of cursor blinking (milliseconds)
      const blinkCursor = setInterval(() => {
        setIsCursorVisible((prev) => !prev); // Toggle cursor visibility
      }, cursorBlinkSpeed);
      
      return () => clearInterval(blinkCursor); // Clean up the interval on component unmount
    }
  }, [isCursorVisible]);

  return (
    <div className="laptop-background">
      <div
        className={`welcome-container ${
          !isMessageVisible ? "hide-message" : ""
        }`}
      >
        <h3
          className="welcome-message"
          style={{
            color: "white",
            fontSize: "2rem", // Adjust font size as needed
            margin: 0, // Ensure no margin affecting positioning
          }}
        >
          <span className="typing-text">{displayedText}</span>
          {isCursorVisible && <span className="blinking-cursor">|</span>} {/* Blinking cursor */}
        </h3>
      </div>

      {/* The zoomable laptop image */}
      <div className={`laptop-container ${isZoomed ? "zoomed" : ""}`}>
        <img src="laptop.png" alt="Laptop" className="laptop-image" />
      </div>

      {/* Show button only when zoom hasn't started */}
      {!isZoomed && (
        <div className="button-container">
          <button onClick={handleClick} className="btn-lets-go">
            Let's Go
          </button>
        </div>
      )}
    </div>
  );
}

export default LandingPage;
