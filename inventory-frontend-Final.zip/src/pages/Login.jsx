import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import loginvalidation from "../validations/loginvalidation";
import { BASE_URL } from "../constants/constants";
import { LOGIN_ACTIONS } from "../store/actions";
import "../CSS/Login.css"; // Import custom CSS for styling

function Login() {
  const dispatch = useDispatch();
  const [user, setUser] = useState({
    userid: "",
    pwd: "",
    role: "", // Ensure role is part of state
  });
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});
  const [errmsg, setErrmsg] = useState();
  const history = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });

    // Validate field on input change
    const updatedErrors = { ...errors };
    const validationError = loginvalidation({ ...user, [name]: value });
    if (!validationError[name]) {
      delete updatedErrors[name];
    }
    setErrors(updatedErrors);
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched({ ...touched, [name]: true });

    const validationError = loginvalidation({ ...user, [name]: value });
    setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);

    const validationErrors = loginvalidation(user);
    setErrors(validationErrors);
    setTouched({
      userid: true,
      pwd: true,
      role: true,
    });

    if (Object.keys(validationErrors).length === 0) {
      axios
        .post(`${BASE_URL}api/users/validate`, user)
        .then((resp) => {
          const result = resp.data;
          console.log(result); // Debug: log the result to verify role
          localStorage.setItem("userid", result.userid);
          localStorage.setItem("uname", result.name);
          localStorage.setItem("role", result.role);
          localStorage.setItem("user", JSON.stringify(result));
          dispatch({ type: LOGIN_ACTIONS.IS_LOGGED_IN });

          // Route based on role
          if (result.role === "Seller") {
            history("/sprofile");
          } else if (result.role === "Admin") {
            history("/category");
          } else if (result.role === "Customer") {
            history("/home");
          } else {
            setErrmsg("Unexpected role. Please contact support.");
          }
        })
        .catch(() => {
          setErrmsg("Invalid username or password.");
        })
        .finally(() => {
          setSubmitted(false);
        });
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-image">
          {/* Add any additional image styling or content here if needed */}
        </div>
        <div className="login-card-body">
          <div className="logo-container">
            <img src="../minilogo.png" alt="Logo" className="login-logo" />
          </div>
          <h4 className="login-title">Welcome back! You've been missed!</h4>
          <form onSubmit={handleSubmit}>
            <div className="login-form-group">
              <label htmlFor="userid">
                User ID<span className="required">*</span>
              </label>
              <input
                type="text"
                id="userid"
                name="userid"
                value={user.userid}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.userid && errors.userid ? "is-invalid" : ""
                }`}
              />
              <div className="login-error-container">
                {touched.userid && errors.userid && (
                  <small className="login-text-danger">{errors.userid}</small>
                )}
              </div>
            </div>
            <div className="login-form-group">
              <label htmlFor="pwd">
                Password<span className="required">*</span>
              </label>
              <input
                type="password"
                id="pwd"
                name="pwd"
                value={user.pwd}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.pwd && errors.pwd ? "is-invalid" : ""
                }`}
              />
              <div className="login-error-container">
                {touched.pwd && errors.pwd && (
                  <small className="login-text-danger">{errors.pwd}</small>
                )}
              </div>
            </div>
            <div className="login-form-group">
              <label htmlFor="role">
                Role<span className="required">*</span>
              </label>
              <select
                id="role"
                name="role"
                value={user.role}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.role && errors.role ? "is-invalid" : ""
                }`}
              >
                <option value="">Select Role</option>
                <option value="Admin">Admin</option>
                <option value="Seller">Seller</option>
                <option value="Customer">Customer</option>
              </select>
              <div className="login-error-container">
                {touched.role && errors.role && (
                  <small className="login-text-danger">{errors.role}</small>
                )}
              </div>
            </div>
            <button
              type="submit"
              className="login-btn"
              disabled={Object.keys(errors).length > 0}
            >
              Login Now
            </button>
          </form>
          {errmsg && <p className="alert alert-danger mt-4">{errmsg}</p>}
          <div className="register-link">
            <p>Don't have an account?</p>
            <div className="d-flex justify-content-center align-items-center">
              <a href="/regsupplier" className="link-btn">
                Register as Seller
              </a>
              <span className="link-divider">&nbsp;/&nbsp;</span>
              <a href="/register" className="link-btn">
                Register as Customer
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
