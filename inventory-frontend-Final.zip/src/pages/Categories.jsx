import { useContext, useEffect, useState } from "react";
import axios from "axios";
import { GlobalInfo } from "../App";
import { BASE_URL } from "../constants/constants";
import "../App.css";

const NAME_REGEX = /^[a-zA-Z\s]{1,20}$/;

function Categories() {
  const [data, setData] = useState([]);
  const [catid, setCatid] = useState(0);
  const [catname, setCatname] = useState("");
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isUpdate, setIsUpdate] = useState(false);
  const { setCats } = useContext(GlobalInfo);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    axios.get(BASE_URL + "api/Category")
      .then((resp) => {
        console.log("Categories loaded:", resp.data);
        if (setCats) {
          setCats(resp.data);
        } else {
          console.error("setCats is not a function");
        }
        setData(resp.data);
      });
  };

  const validateCategoryName = async (name) => {
    let error = "";
    const trimmedName = name.trim();
    
    if (!trimmedName) {
      error = "Category Name is required";
    } else if (trimmedName.length > 20) {
      error = "Category Name must be 20 characters or fewer.";
    } else if (!NAME_REGEX.test(trimmedName)) {
      error = "Category Name should contain only letters.";
    } else if (await isDuplicateCategoryName(trimmedName)) {
      error = "Category Name already exists.";
    }
    
    return error;
  };

  const isDuplicateCategoryName = async (name) => {
    try {
      const response = await axios.get(BASE_URL + "api/Category");
      const categories = response.data;
      const exists = categories.some(category => category.catname.toLowerCase() === name.toLowerCase());
      return exists;
    } catch (error) {
      console.error("Error checking for duplicate category name:", error);
      return false;
    }
  };

  const handleBlur = () => {
    setTouched({ ...touched, catname: true });
    validateCategoryName(catname).then(error => {
      setErrors({ ...errors, catname: error });
    });
  };

  const handleInput = (e) => {
    const value = e.target.value;
    const sanitizedValue = value.replace(/\s+/g, " ").trimStart();
    setCatname(sanitizedValue);
    
    // Always validate on input change, regardless of mode
    validateCategoryName(sanitizedValue).then(error => {
      setErrors({ ...errors, catname: error });
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const error = await validateCategoryName(catname);
    setTouched({ catname: true });
    setErrors({ catname: error });

    if (!error) {
      const requestPayload = {
        catid,
        catname: catname.trim()
      };

      axios.post(BASE_URL + "api/Category", requestPayload)
        .then(() => {
          loadData();
          setCatname("");
          setCatid(0);
          setIsUpdate(false);
          alert(isUpdate ? "Category updated successfully" : "Category added successfully");
        })
        .catch(() => {
          alert("Failed to save category");
        });
    }
  };

  const editCategory = (x) => {
    setCatid(x.catid);
    setCatname(x.catname);
    setIsUpdate(true);
    setTouched({ catname: false }); // Reset touched state on edit
  };

  const deleteCategory = async (catid) => {
    if (window.confirm("Are you sure to delete this category?")) {
      try {
        // Check if there are products associated with the category
        const productsResponse = await axios.get(`${BASE_URL}api/products?catid=${catid}`);
        const products = productsResponse.data;
  
      
          // No products associated, proceed with deletion
          await axios.delete(`${BASE_URL}api/Category/${catid}`);
          loadData();
          alert("Category deleted successfully");
        
      } catch (error) {
        // Handle errors
        console.error("Error deleting category:", error);
        alert("Cannot delete category as products are associated with it.");
      }
    }
  };
  

  return (
    <div className="container">
      <div className="card shadow">
        <div className="card-body">
          <h4 className="p-3">Categories</h4>
          <div className="row">
            <div className="col-sm-7">
              <table className="table table-bordered">
                <thead className="table-dark">
                  <tr>
                    <th>Category</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((x) => (
                    <tr key={x.catid}>
                      <td>{x.catname}</td>
                      <td>
                        <button
                          onClick={() => editCategory(x)}
                          className="btn btn-primary btn-sm mr-2"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => deleteCategory(x.catid)}
                          className="btn btn-danger btn-sm"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="col-sm-4">
              <h4 className="AddCategory-Name">{isUpdate ? "Update Category" : "Add Category"}</h4>
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label className="Category-Name">Category Name<span style={{ color: 'red' }}>*</span></label>
                  <input
                    type="text"
                    name="catname"
                    value={catname}
                    onChange={handleInput}
                    onBlur={handleBlur}
                    className={`form-control ${touched.catname && errors.catname ? "is-invalid" : ""}`}
                  />
                  <div className="admincat-error-message">
                    {touched.catname && errors.catname && (
                      <small className="text-danger">{errors.catname}</small>
                    )}
                  </div>
                </div>
                <button type="submit" className="admincat-btn" disabled={!!errors.catname}>
                  {isUpdate ? "Update Category" : "Add Category"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Categories;
