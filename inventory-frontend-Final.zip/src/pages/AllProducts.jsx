import axios from "axios";
import { useEffect, useState } from "react";
import { useLocation, useParams, Link } from "react-router-dom"; // Import Link
import { BASE_URL } from "../constants/constants";
import Product from "../components/Product";
import "../CSS/Home.css"; // Import custom CSS for styling

// Modal Component
const Modal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>Work in Progress</h2>
        <p>The details you are looking for are currently under development by Manthan Patil.</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

function AllProduct() {
  const [products, setProducts] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false); // State for modal visibility
  const { subcat } = useParams();
  const location = useLocation();

  const loadDataFromServer = () => {
    axios.get(BASE_URL + "api/products").then((resp) => {
      setProducts(resp.data);
    });
  };

  useEffect(() => {
    if (subcat !== undefined) {
      axios.get(BASE_URL + "api/products/cats/" + subcat).then((resp) => {
        console.log(resp.data);
        setProducts(resp.data);
      });
    } else {
      loadDataFromServer();
    }
  }, [subcat]);

  useEffect(() => {
    if (location.state != null) {
      const { cat, search } = location.state;
      axios
        .get(`${BASE_URL}api/products/search?cat=${cat}&search=${search}`)
        .then((resp) => {
          console.log(resp.data);
          setProducts(resp.data);
        });
    }
  }, [location.state]);

  const handleOpenModal = (e) => {
    e.preventDefault(); // Prevent navigation
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <div className="header-image" style={{ position: "relative" }}>
        {/* Image outside all products */}
        <img
          alt="Promotional"
          src="./Homepic.png" // Adjust this path as necessary
          className="promo-image"
        />

        {/* Link on top of the image */}
        <Link to="#" className="more-detail-link" onClick={handleOpenModal}>
          More Detail
        </Link>
      </div>

      <div className="container-fluid" style={{ width: "90%" }}>
        {products.length === 0 ? (
          <h5>No Products available</h5>
        ) : (
          <div className="card-body">
            <div className="row">
              {products.map((x) => (
                <Product key={x.prodid} x={x} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modal Component */}
      <Modal isOpen={isModalOpen} onClose={handleCloseModal} />
    </>
  );
}

export default AllProduct;
