﻿using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InventoryMgmt_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository categoryRepository;

        public CategoryController(ICategoryRepository categoryRepository)
        {
            this.categoryRepository = categoryRepository;
        }

        [HttpGet]
        public IActionResult Get() => Ok(categoryRepository.GetAllCategories());
        

        [HttpPost]
        public IActionResult SaveCategory(Category category)
        {
            categoryRepository.SaveCategory(category);
            return Ok(new { Message = "Category saved successfully"});
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id) { 
            categoryRepository.DeleteCategory(id);
            return Ok(new { Message = "Category deleted successfully"});
        }
    }
}
