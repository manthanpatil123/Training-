﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace InventoryMgmt_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductRepository productRepository;

        public ProductsController(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        [HttpGet]
        public IActionResult Get(string sellerid)
        {
            if (string.IsNullOrEmpty(sellerid))
            {
                return Ok(productRepository.GetAllProducts());
            }
            else
            {
                return Ok(productRepository.GetProductBySeller(sellerid));
            }
        }

        [HttpGet("cats/{catid}")]
        public IActionResult GetByCategory(int catid)
        {
            return Ok(productRepository.GetProductsByCategory(catid));    
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return Ok(productRepository.GetProductById(id));
        }

        [HttpGet("search")]
        public IActionResult Search(string name)
        {
            return Ok(productRepository.GetProductByName(name));
        }

        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id,[FromForm] AddProductDto dto)
        {
            dto.Prodid = id;
            productRepository.UpdateProduct(dto);
            return Ok(new {Message = "Product updated successfully"});
        }

        [HttpPost]
        public IActionResult AddProduct([FromForm]AddProductDto product)
        {
            productRepository.SaveProduct(product);
            return Ok(new { Message = "Product saved successfully" });
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                productRepository.DeleteProduct(id);
                return Ok(new { Message = "Product deleted successfully" });
            }
            catch (Exception)
            {
                return BadRequest("Cannot delete product");
            }
        }
    }
}
