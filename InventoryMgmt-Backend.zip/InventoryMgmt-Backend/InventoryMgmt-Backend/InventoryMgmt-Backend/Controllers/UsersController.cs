﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InventoryMgmt_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository userRepository;

        public UsersController(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        [HttpPost("validate")]
        public IActionResult Validate(LoginDto dto)
        {
            var user = userRepository.Validate(dto);
            if(user is null)
            {
                return NotFound();  
            }
            return Ok(user);
        }

        [HttpGet("verify")]
        public IActionResult Verify(string userid)
        {
            var result = userRepository.Verify(userid);
            return Ok(result);
        }

        [HttpPost("register")]
        public IActionResult Register(UserRegisterRequest user)
        {
            try
            {
                userRepository.RegisterUser(user);
                return Ok(new { Message = "User registered successfully" });
            }
            catch (InvalidOperationException ex)
            {
                // Handle specific exception for username not available
                return Conflict(new { Message = ex.Message }); // 409 Conflict
            }
           
        }

        [HttpGet]
        public IActionResult GetAll() 
        {
            return Ok(userRepository.GetAll());
        }

        [HttpGet("byrole")]
        public IActionResult GetAllByRole(string role)
        {
            return Ok(userRepository.FindAllByRole(role));
        }
    }
}
