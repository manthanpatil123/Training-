﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InventoryMgmt_Backend.Repsitories
{
    public class ProductRepository : IProductRepository
    {
        private readonly InventoryDbContext context;
        private readonly IWebHostEnvironment env;

        public ProductRepository(InventoryDbContext context, IWebHostEnvironment env)
        {
            this.context = context;
            this.env = env;
        }

        public void DeleteProduct(int id)
        {
            var product = GetProductById(id);
            context.Products.Remove(product);
            context.SaveChanges();
        }

        public List<Product> GetAllProducts()
        {
            return context.Products.AsNoTracking().Include(x => x.Category).ToList();
        }

        public Product GetProductById(int id)
        {
            return context.Products.AsNoTracking().Include(x => x.Category).Include(_ => _.Seller).First(_ => _.Prodid == id);
        }

        public List<Product> GetProductByName(string name)
        {
            return context.Products.AsNoTracking().Where(x => EF.Functions.Like(x.Pname,$"%{name}%")).ToList();
        }

        public List<Product> GetProductBySeller(string sellerId)
        {
            return context.Products.AsNoTracking().Include(_ => _.Category).Where(x=>x.Sellerid == sellerId).ToList();
        }

        public List<Product> GetProductsByCategory(int categoryId)
        {
            return context.Products.AsNoTracking().Include(_ => _.Category).Where(x => x.Pcat == categoryId).ToList();
        }

        public void SaveProduct(AddProductDto dto)
        {
            var filename = Guid.NewGuid() + Path.GetExtension(dto.Pic.FileName);
            using (FileStream stream = new FileStream(Path.Combine(Path.Combine(env.WebRootPath, "images", filename)), FileMode.Create))
            {
                dto.Pic.CopyTo(stream);
            }
            var product = new Product
            {
                Pcat = dto.Pcat,
                Pname = dto.Pname,
                Price = dto.Price,
                Qty = dto.Qty,
                Sellerid = dto.Sellerid,  
                Photo = filename,
            };
            context.Products.Add(product);
            context.SaveChanges();
        }

        public void UpdateProduct(AddProductDto dto)
        {
            var product = context.Products.Find(dto.Prodid);
            if (dto.Pic != null)
            { 
                //delete existing file
                File.Delete(Path.Combine(env.WebRootPath, "images", product.Photo));
                var filename = Guid.NewGuid() + Path.GetExtension(dto.Pic.FileName);
                using (FileStream stream = new FileStream(Path.Combine(Path.Combine(env.WebRootPath, "images", filename)), FileMode.Create))
                {
                    dto.Pic.CopyTo(stream);
                }
                product.Photo = filename;
            }

            product.Pcat = dto.Pcat;
            product.Pname = dto.Pname;
            product.Price = dto.Price;
            product.Qty = dto.Qty;
            context.Products.Update(product);
            context.SaveChanges();
        }
    }
}
