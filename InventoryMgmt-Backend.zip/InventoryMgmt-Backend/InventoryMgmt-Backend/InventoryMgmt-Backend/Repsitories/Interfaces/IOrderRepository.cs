﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;

namespace InventoryMgmt_Backend.Repsitories.Interfaces
{
    public interface IOrderRepository
    {
        void PlaceOrder(PlaceOrderDto dto);
        List<Order> AllOrders(string customerId);
        Order GetOrder(int orderId);
        List<Order> SellerOrders(string sellerId);
        void ConfirmOrder(int orderDetailsId);
    }
}
