﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;

namespace InventoryMgmt_Backend.Repsitories.Interfaces
{
    public interface IProductRepository
    {
        void SaveProduct(AddProductDto product);
        List<Product> GetAllProducts();
        void DeleteProduct(int id);
        void UpdateProduct(AddProductDto product);
        Product GetProductById(int id);
        List<Product> GetProductByName(string name);
        List<Product> GetProductsByCategory(int categoryId);
        List<Product> GetProductBySeller(string sellerId);
    }
}
