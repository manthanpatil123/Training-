﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InventoryMgmt_Backend.Repsitories
{
    public class OrdersRepository : IOrderRepository
    {
        private readonly InventoryDbContext context;

        public OrdersRepository(InventoryDbContext context)
        {
            this.context = context;
        }

        public List<Order> AllOrders(string customerId)
        {
            if(string.IsNullOrEmpty(customerId))
            {
                return context.Orders.AsNoTracking().Include(x=>x.Payment).Include(x => x.Customer).Include(_ => _.Orderdetails).ThenInclude(x=>x.Prod).ToList();
            }

            return context.Orders.AsNoTracking().Include(x => x.Payment).Include(x=>x.Customer).Include(_ => _.Orderdetails).ThenInclude(x => x.Prod).Where(_ => _.Customerid == customerId).ToList();  
        }

        public List<Order> SellerOrders(string sellerId)
        {
            var orders = context.Orderdetails.Where(x => x.Prod.Sellerid == sellerId).Select(x=>x.Orderid).ToList();
            return context.Orders.AsNoTracking().Include(x => x.Payment).Include(x => x.Customer).Include(_ => _.Orderdetails.Where(_ => _.Prod.Sellerid==sellerId)).ThenInclude(x => x.Prod).Where(_ => orders.Contains(_.Orderid)).ToList();
        }

        public Order GetOrder(int orderId)
        {
            return context.Orders.AsNoTracking().Include(_ => _.Address).Include(_ => _.Orderdetails).ThenInclude(x => x.Prod).Include(_ => _.Payment).FirstOrDefault(o => o.Orderid == orderId);
        }

        public void ConfirmOrder(int orderDetailsId)
        {
            var details = context.Orderdetails.Find(orderDetailsId);
            details.Status = "Confirmed";
            var product = context.Products.First(x=> x.Prodid == details.Prodid);
            product.Qty -= details.Qty.Value;
            context.SaveChanges();
        }

        public void PlaceOrder(PlaceOrderDto dto)
        {
            context.Addresses.Add(dto.Address);
            context.SaveChanges();
            dto.Payment.Paymentdate = DateTime.Now;
            context.Payments.Add(dto.Payment);
            context.SaveChanges();
            Order order = new Order
            {
                Addressid = dto.Address.Id,
                Paymentid = dto.Payment.Id,
                Orderdate = DateTime.Now,
                Customerid = dto.CustomerId
            };
            context.Orders.Add(order);
            context.SaveChanges();
            foreach(var item in dto.Cart)
            {
                Orderdetail od = new Orderdetail
                {
                    Orderid = order.Orderid,
                    Prodid = item.Prodid,
                    Qty = item.Qty,
                    Status = "Pending"
                };
                context.Orderdetails.Add(od);
            }
            context.SaveChanges();
        }
    }
}
