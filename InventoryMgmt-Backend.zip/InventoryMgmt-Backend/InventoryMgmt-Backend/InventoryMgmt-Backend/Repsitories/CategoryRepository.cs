﻿using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InventoryMgmt_Backend.Repsitories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly InventoryDbContext context;

        public CategoryRepository(InventoryDbContext context)
        {
            this.context = context;
        }
        public void DeleteCategory(int id)
        {
            var category = context.Categories.First(_ => _.Catid == id);
            context.Categories.Remove(category);
            context.SaveChanges();
        }

        public List<Category> GetAllCategories()
        {
            return context.Categories.AsNoTracking().ToList();
        }

        public void SaveCategory(Category category)
        {
            if(category.Catid == 0)
            {
                context.Categories.Add(category);
            }
            else
            {
                context.Categories.Update(category);
            }
            context.SaveChanges();
        }
    }
}
