﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InventoryMgmt_Backend.Repsitories
{
    public class UserRepository : IUserRepository
    {
        private readonly InventoryDbContext _context;
        public UserRepository(InventoryDbContext context)
        {
            _context = context;
        }

        public List<User> FindAllByRole(string role)
        {
            return _context.Users.AsNoTracking().Where(x=>x.Role == role).ToList();
        }

        public List<User> GetAll()
        {
            return _context.Users.AsNoTracking().ToList();
        }

       public void RegisterUser(UserRegisterRequest userRequest)
{
    try
    {
        // Check if the username already exists
        bool userExists = _context.Users.Any(u => u.Userid == userRequest.Userid);
        
        if (userExists)
        {
            // Throw a custom exception or handle the error as needed
            throw new InvalidOperationException("Username is not available.");
        }

        var user = new User
        {
            Name = userRequest.Name,
            City = userRequest.City,
            Gender = userRequest.Gender,
            Phone = userRequest.Phone,
            Pwd = userRequest.Pwd,
            Role = userRequest.Role,
            Userid = userRequest.Userid,
            Createdon = DateTime.Now
        };

        _context.Users.Add(user);
        _context.SaveChanges();
    }
    catch (InvalidOperationException ex)
    {
        // Log the specific exception for username not available
        Console.WriteLine($"Registration error: {ex.Message}");
        throw; // Re-throw the exception to be handled by the controller
    }
    catch (Exception ex)
    {
        // Log other general exceptions
        Console.WriteLine($"An error occurred while registering the user: {ex.Message}");
        throw; // Re-throw the exception to be handled by the controller
    }
}



        public void UpdateProfile(User user)
        {
            throw new NotImplementedException();
        }

        public User Validate(LoginDto dto)
        {
            var user = _context.Users.AsNoTracking().FirstOrDefault(_ => _.Userid == dto.UserId && _.Pwd == dto.Pwd && _.Role == dto.Role);
            return user;
        }
    }
}
