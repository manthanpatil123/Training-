﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace InventoryMgmt_Backend.Models
{
    public partial class User
    {
        public User()
        {
            Orders = new HashSet<Order>();
            Products = new HashSet<Product>();
        }

        public string Userid { get; set; }
        public string Name { get; set; }
        [JsonIgnore]
        public string Pwd { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public string City { get; set; }
        public DateTime? Createdon { get; set; }
        public string Role { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
