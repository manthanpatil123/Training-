﻿namespace InventoryMgmt_Backend.Models
{
    public partial class Orderdetail
    {
        public int Id { get; set; }
        public int? Orderid { get; set; }
        public int? Prodid { get; set; }
        public int? Qty { get; set; }
        public string Status { get; set; }

        public virtual Order Order { get; set; }
        public virtual Product Prod { get; set; }
    }
}
