﻿using System;
using System.Collections.Generic;

namespace InventoryMgmt_Backend.Models
{
    public partial class Payment
    {
        public Payment()
        {
            Orders = new HashSet<Order>();
        }

        public int Id { get; set; }
        public string Nameoncard { get; set; }
        public string Cardno { get; set; }
        public decimal? Amount { get; set; }
        public DateTime? Paymentdate { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
