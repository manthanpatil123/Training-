﻿using System;
using System.Collections.Generic;

namespace InventoryMgmt_Backend.Models
{
    public partial class Order
    {
        public Order()
        {
            Orderdetails = new HashSet<Orderdetail>();
        }

        public int Orderid { get; set; }
        public DateTime? Orderdate { get; set; }
        public int? Addressid { get; set; }
        public int? Paymentid { get; set; }
        public string Customerid { get; set; }
        

        public virtual Address Address { get; set; }
        public virtual User Customer { get; set; }
        public virtual Payment Payment { get; set; }
        public virtual ICollection<Orderdetail> Orderdetails { get; set; }
    }
}
