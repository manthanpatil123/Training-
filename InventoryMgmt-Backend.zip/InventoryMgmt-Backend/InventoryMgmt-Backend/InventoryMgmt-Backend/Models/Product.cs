﻿using System;
using System.Collections.Generic;

namespace InventoryMgmt_Backend.Models
{
    public partial class Product
    {
        public Product()
        {
            Orderdetails = new HashSet<Orderdetail>();
        }

        public int Prodid { get; set; }
        public string Pname { get; set; }
        public string Photo { get; set; }
        public int? Pcat { get; set; }
        public int Qty { get; set; }
        public decimal? Price { get; set; }
        public string Sellerid { get; set; }

        public virtual Category Category { get; set; }
        public virtual User Seller { get; set; }
        public virtual ICollection<Orderdetail> Orderdetails { get; set; }
    }
}
