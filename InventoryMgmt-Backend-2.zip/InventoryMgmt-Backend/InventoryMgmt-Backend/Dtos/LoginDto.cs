﻿namespace InventoryMgmt_Backend.Dtos
{
    public class LoginDto
    {
        public string UserId { get; set; }
        public string Pwd { get; set; }
        public string Role { get; set; }
    }
}
