﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InventoryMgmt_Backend.Repsitories
{
    public class UserRepository : IUserRepository
    {
        private readonly InventoryDbContext _context;
        public UserRepository(InventoryDbContext context)
        {
            _context = context;
        }

        public List<User> FindAllByRole(string role)
        {
            return _context.Users.AsNoTracking().Where(x=>x.Role == role).ToList();
        }

        public List<User> GetAll()
        {
            return _context.Users.AsNoTracking().ToList();
        }

        public void RegisterUser(UserRegisterRequest userRequest)
        {
            var user = new User
            {
                Name = userRequest.Name,
                City = userRequest.City,
                Gender = userRequest.Gender,
                Phone = userRequest.Phone,
                Pwd = userRequest.Pwd,
                Role = userRequest.Role,
                Userid = userRequest.Userid,
                Createdon = DateTime.Now
            };

            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void UpdateProfile(User user)
        {
            throw new NotImplementedException();
        }

        public User Validate(LoginDto dto)
        {
            var user = _context.Users.AsNoTracking().FirstOrDefault(_ => _.Userid == dto.UserId && _.Pwd == dto.Pwd && _.Role == dto.Role);
            return user;
        }
    }
}
