﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Models;

namespace InventoryMgmt_Backend.Repsitories.Interfaces
{
    public interface IUserRepository
    {
        void RegisterUser(UserRegisterRequest user);
        List<User> GetAll();
        List<User> FindAllByRole(string role);
        User Validate(LoginDto dto);
        void UpdateProfile(User user);
    }
}
