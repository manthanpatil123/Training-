﻿using InventoryMgmt_Backend.Models;

namespace InventoryMgmt_Backend.Repsitories.Interfaces
{
    public interface ICategoryRepository
    {
        void SaveCategory(Category category);
        List<Category> GetAllCategories();  
        void DeleteCategory(int id);
    }
}
