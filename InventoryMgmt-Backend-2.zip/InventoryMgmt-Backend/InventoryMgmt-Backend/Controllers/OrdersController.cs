﻿using InventoryMgmt_Backend.Dtos;
using InventoryMgmt_Backend.Repsitories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InventoryMgmt_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository orderRepository;

        public OrdersController(IOrderRepository orderRepository)
        {
            this.orderRepository = orderRepository;
        }

        [HttpPost]
        public IActionResult PlaceOrder([FromBody] PlaceOrderDto dto)
        {
            this.orderRepository.PlaceOrder(dto);
            return Ok(new {Message = "Order Placed successfully"});
        }

        [HttpGet]
        public IActionResult GetOrders(string custid)
        {
            return Ok(orderRepository.AllOrders(custid));
        }

        [HttpGet("sellers")]
        public IActionResult GetSellerOrders(string sellerid)
        {
            return Ok(orderRepository.SellerOrders(sellerid));
        }

        [HttpGet("{id}")]
        public IActionResult GetOrderDetails(int id)
        {
            return Ok(orderRepository.GetOrder(id));
        }

        [HttpGet("confirm/{id}")]
        public IActionResult ConfirmItem(int id)
        {
            orderRepository.ConfirmOrder(id);
            return Ok(new { Message = "Item confirmed successfully" });
        }
    }
}
