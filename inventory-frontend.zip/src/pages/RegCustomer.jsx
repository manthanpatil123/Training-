import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import uservalidation from "../validations/uservalidation";
import { BASE_URL } from "../constants/constants";
import "../CSS/RegCustomer.css"; // Import custom CSS for styling

function RegCustomer() {
  const [user, setUser] = useState({
    name: "",
    city: "",
    userid: "",
    pwd: "",
    cpwd: "",
    phone: "",
    gender: "",
    role: "Customer", // Changed role to "Customer"
  });
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });

    const updatedErrors = { ...errors };
    const validationError = uservalidation({ ...user, [name]: value });
    if (!validationError[name]) {
      delete updatedErrors[name];
    }
    setErrors(updatedErrors);
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const trimmedValue = value.trim().replace(/\s+/g, " ");

    setUser({ ...user, [name]: trimmedValue });
    setTouched({ ...touched, [name]: true });

    const validationError = uservalidation({ ...user, [name]: trimmedValue });
    setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));

    if (name === "userid") {
      axios
        .get(`${BASE_URL}api/users/verify?userid=${trimmedValue}`)
        .then((resp) => {
          if (resp.data) {
            setErrors((prevErrors) => ({
              ...prevErrors,
              userid: "Userid already exists",
            }));
          }
        });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const allFieldsTouched = Object.keys(user).reduce((acc, key) => {
      acc[key] = true;
      return acc;
    }, {});
    setTouched(allFieldsTouched);

    const validationErrors = uservalidation(user);
    if (!user.gender) {
      validationErrors.gender = "Gender is required";
    }
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
    } else {
      setSubmitted(false);
    }
  };

  useEffect(() => {
    if (Object.keys(errors).length === 0 && submitted) {
      axios
        .post(`${BASE_URL}api/users/register`, user)
        .then((resp) => {
          alert("Customer registered successfully");
          navigate("/login");
        })
        .catch(() => {
          alert("Entered User Name is Not Available");
        })
        .finally(() => {
          setSubmitted(false);
        });
    }
  }, [errors, submitted, user, navigate]);

  return (
    <div className="regcustomer-container">
      <div className="regcustomer-card">
        <div className="regcus-image">
          {/* Add any additional image styling or content here if needed */}
        </div>
        <div className="regcustomer-card-body">
          <div className="logo-container">
            <img
              src="../minilogo.png"
              alt="Logo"
              className="regsupplier-logo"
            />
          </div>
          <h4 className="login-title">Customer Registration</h4>
          <form onSubmit={handleSubmit}>
            <div className="cus-form-group">
              <label htmlFor="name">
                Name<span className="required">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={user.name}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.name && !user.name ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="regcus-error-container">
                {touched.name && errors.name && (
                  <small className="text-danger">{errors.name}</small>
                )}
              </div>
            </div>
            <div className="cus-form-group">
              <label htmlFor="city">
                City<span className="required">*</span>
              </label>
              <input
                type="text"
                id="city"
                name="city"
                value={user.city}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.city && !user.city ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="regcus-error-container">
                {touched.city && errors.city && (
                  <small className="text-danger">{errors.city}</small>
                )}
              </div>
            </div>
            <div className="cus-form-group">
              <label htmlFor="gender">
                Gender<span className="required">*</span>
              </label>
              <select
                id="gender"
                name="gender"
                value={user.gender}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.gender && !user.gender ? "is-invalid" : ""
                }`}
              >
                <option value="">Select Gender</option>
                <option>Male</option>
                <option>Female</option>
              </select>{" "}
              <div className="regcus-error-container">
                {touched.gender && errors.gender && (
                  <small className="text-danger">{errors.gender}</small>
                )}
              </div>
            </div>
            <div className="cus-form-group">
              <label htmlFor="userid">
                User ID<span className="required">*</span>
              </label>
              <input
                type="text"
                id="userid"
                name="userid"
                value={user.userid}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.userid && !user.userid ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="regcus-error-container">
                {touched.userid && errors.userid && (
                  <small className="text-danger">{errors.userid}</small>
                )}
              </div>
            </div>
            <div className="cus-form-group">
              <label htmlFor="phone">
                Phone<span className="required">*</span>
              </label>
              <input
                type="text"
                id="phone"
                name="phone"
                maxLength="10"
                value={user.phone}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.phone && !user.phone ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="regcus-error-container">
                {touched.phone && errors.phone && (
                  <small className="text-danger">{errors.phone}</small>
                )}
              </div>
            </div>
            <div className="cus-form-group">
              <label htmlFor="pwd">
                Password<span className="required">*</span>
              </label>
              <input
                type="password"
                id="pwd"
                name="pwd"
                value={user.pwd}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.pwd && !user.pwd ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="regcus-error-container">
                {touched.pwd && errors.pwd && (
                  <small className="text-danger">{errors.pwd}</small>
                )}
              </div>
            </div>
            <div className="cus-form-group">
              <label htmlFor="cpwd">
                Confirm Password<span className="required">*</span>
              </label>
              <input
                type="password"
                id="cpwd"
                name="cpwd"
                value={user.cpwd}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.cpwd && !user.cpwd ? "is-invalid" : ""
                }`}
              />{" "}
              <div className="regcus-error-container">
                {touched.cpwd && errors.cpwd && (
                  <small className="text-danger">{errors.cpwd}</small>
                )}
              </div>
            </div>
            <button
              type="submit"
              className="cus-btn"
              disabled={Object.keys(errors).length > 0}
            >
              Register Now
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default RegCustomer;
