import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import uservalidation from "../validations/uservalidation";
import { BASE_URL } from "../constants/constants";

function RegCustomer() {
    const [user, setUser] = useState({
        name: "",
        city: "",
        userid: "",
        pwd: "",
        cpwd: "",
        phone: "",
        gender: "",
        role: "Customer"
    });
    const [errors, setErrors] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const history = useNavigate();

    const handleInput = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });

        // Clear error for the field being updated if it's now valid
        const updatedErrors = { ...errors };
        const validationError = uservalidation({ ...user, [name]: value });
        if (!validationError[name]) {
            delete updatedErrors[name];
        }
        setErrors(updatedErrors);
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        const validationError = uservalidation({ ...user, [name]: value });
        setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const validationErrors = uservalidation(user);
        if (!user.gender) {
            validationErrors.gender = "Gender is required";
        }
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length === 0) {
            setSubmitted(true);
        } else {
            setSubmitted(false);
        }
    };

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitted) {
            axios.post(`${BASE_URL}api/users/register`, user)
                .then((resp) => {
                    alert("Customer registered successfully");
                    history("/login");
                })
                .catch(() => {
                    alert("Entered User Name is Not Available");
                })
                .finally(() => {
                    setSubmitted(false); // Reset submitted state after registration attempt
                });
        }
    }, [errors, submitted, user, history]);

    return (
        <div className="container">
            <div className="card shadow mt-3">
                <div className="card-body">
                    <div className="row">
                        <div className="col-sm-6 mx-auto">
                            <h4 className="text-center p-2">Customer Registration</h4>
                            <form onSubmit={handleSubmit}>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Name
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="name"
                                            value={user.name}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.name && <small className="text-danger float-right">{errors.name}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>City
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="city"
                                            value={user.city}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.city && <small className="text-danger float-right">{errors.city}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Gender
                                    </label>
                                    <div className="col-sm-8">
                                        <select
                                            name="gender"
                                            value={user.gender}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        >
                                            <option value="">Select Gender</option>
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>
                                        {errors.gender && <small className="text-danger float-right">{errors.gender}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>User ID
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="userid"
                                            value={user.userid}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.userid && <small className="text-danger float-right">{errors.userid}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Phone
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            maxLength="10"
                                            name="phone"
                                            value={user.phone}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.phone && <small className="text-danger float-right">{errors.phone}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Password
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="password"
                                            name="pwd"
                                            value={user.pwd}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.pwd && <small className="text-danger float-right">{errors.pwd}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Confirm Password
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="password"
                                            name="cpwd"
                                            value={user.cpwd}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.cpwd && <small className="text-danger float-right">{errors.cpwd}</small>}
                                    </div>
                                </div>
                                <button className="btn btn-primary float-right">Register Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default RegCustomer;
