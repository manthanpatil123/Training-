import "../CSS/SellerProfile.css"; // Import custom CSS for styling

function SellerProfile() {
  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <div className="seller-profile-container">
      <div className="seller-profile-card">
        <div
          className="seller-profile-image"
          style={{ width: "180%", height: "550px" }}
        >
          <div className="idcardname">Name: {user.name}</div>
          {/* Profile image or placeholder can go here */}
        </div>
        <div className="seller-profile-content">
          <br></br>
          <br></br>
          <br></br>
          <br></br>
          <br></br>
          <br></br>
          <h4 className="seller-profile-title">Seller Profile</h4>
          <br></br>

          <h4>Welcome {user.name}</h4>
          <h5>City: {user.city}</h5>
          <h5>User Id: {user.userid}</h5>
          <h5>Contact No: {user.phone}</h5>
        </div>
      </div>
    </div>
  );
}

export default SellerProfile;
