import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BASE_URL } from "../constants/constants";

function MyProducts(){
    const sellerid=localStorage.getItem("userid");
    const [products,setProducts]=useState([])
    useEffect(()=>{
        axios.get(BASE_URL+"api/products?sellerid="+sellerid)
        .then(resp=>{
            console.log(resp.data)
            setProducts(resp.data)
            console.log(products)
        })
    },[])

    const deleteProduct = (prodid)=>{
        let resp=window.confirm('Are you sure to delete this product ?');
        if(resp){
            axios.delete(BASE_URL+"api/products/"+prodid)
            .then(resp=>{
                alert("Product deleted successfully")
                axios.get(BASE_URL+"api/products?sellerid="+sellerid)
                .then(resp=>{
                    console.log(resp.data)
                    setProducts(resp.data)
                    console.log(products)
                })
            })            
        }
    }
    try {
        return (
            <div className="container">
                <div className="card shadow bg-transparent text-white">
                    <div className="card-body">                    
                <h4>My Products</h4>
                <table className="table table-bordered table-sm">
                    <thead className="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Available Qty</th>
                            <th>Price</th>
                            <th>Action</th>                                
                        </tr>
                    </thead>
                    <tbody>
                    {products.map(x=>(
                        <tr key={x.prodid}>
                            <td><img alt="Product" style={{width:"80px",height:"80px"}} src={BASE_URL+'/images/'+x.photo} className="img-thumbnail mr-2"/>{x.pname}</td>
                            <td>{x.category.catname}</td>
                            <td>{x.qty}</td>
                            <td>&#8377; {x.price}</td>
                            <td>
                                <Link to={"/edit/"+x.prodid} className="btn btn-primary btn-sm mr-2">Edit</Link>
                                <button onClick={()=>deleteProduct(x.prodid)} className="btn btn-danger btn-sm">Delete</button>
                            </td>                                
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
            
            </div>
                </div>
        )
        
    } catch (error) {
        alert("Cannot Delete the Cutomer Orderd Product")
        
    }
    
}

export default MyProducts;