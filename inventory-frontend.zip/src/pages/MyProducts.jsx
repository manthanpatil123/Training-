import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BASE_URL } from "../constants/constants";
import "../CSS/MyProduct.css"; // Updated custom CSS for Add Product
function MyProducts() {
  const sellerid = localStorage.getItem("userid");
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get(BASE_URL + "api/products?sellerid=" + sellerid).then((resp) => {
      console.log(resp.data);
      // Filter out products with negative quantity
      const validProducts = resp.data.filter((product) => product.qty >= 0);
      setProducts(validProducts);
      console.log(validProducts);
    });
  }, [sellerid]);

  const deleteProduct = (prodid) => {
    let resp = window.confirm("Are you sure to delete this product?");
    if (resp) {
      axios
        .delete(BASE_URL + "api/products/" + prodid)
        .then((resp) => {
          alert("Product deleted successfully");
          axios
            .get(BASE_URL + "api/products?sellerid=" + sellerid)
            .then((resp) => {
              const validProducts = resp.data.filter(
                (product) => product.qty >= 0
              );
              setProducts(validProducts);
            });
        })
        .catch((err) => {
          console.log(err.response.data);
          alert("Cannot delete product that cusotmer bought");
        });
    }
  };

  try {
    return (
      <div className="container">
        <div className="card shadow bg-transparent text-white">
          <div className="card-body">
            <h4 className="p-2 text-center" style={{ color: "black" }}>
              My Products
            </h4>

            <table className="table table-bordered table-light table-hover table-striped table-sm">
              <thead className="table-dark">
                <tr>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Available Qty</th>
                  <th>Price</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {products.length > 0 ? (
                  products.map((x) => (
                    <tr key={x.prodid}>
                      <td>
                        <img
                          alt="Product"
                          style={{ width: "80px", height: "80px" }}
                          src={BASE_URL + "/images/" + x.photo}
                          className="img-thumbnail mr-2"
                        />
                        {x.pname}
                      </td>
                      <td>{x.category.catname}</td>
                      <td>{x.qty}</td>
                      <td>&#8377; {x.price}</td>
                      <td>
                        <Link
                          to={"/edit/" + x.prodid}
                          className=" myproductedit-btn"
                        >
                          Edit
                        </Link>
                        <button
                          onClick={() => deleteProduct(x.prodid)}
                          className="myproductdelete-btn"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5">
                      No products available or all products have invalid
                      quantities.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    alert("Cannot Delete the Customer Ordered Product");
    return null; // Optional: return null to avoid rendering anything in case of error
  }
}

export default MyProducts;
