import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import productvalidation from "../validations/productvalidation";
import { BASE_URL } from "../constants/constants";

function AddProduct() {
    const sellerid = localStorage.getItem("userid");

    const [product, setProduct] = useState({
        pname: "",
        pcat: "",
        price: "",
        descr: "",
        qty: 1,
        sellerId: sellerid,
        photo: null
    });

    const [errors, setErrors] = useState({});
    const [selectedPhoto, setSelectedPhoto] = useState(null);
    const [submitted, setSubmitted] = useState(false);
    const navigate = useNavigate();
    const [cats, setCats] = useState([]);

    useEffect(() => {  
        axios.get(BASE_URL + 'api/category')
            .then(resp => setCats(resp.data));
    }, []);

    const handleInput = (e) => {
        const { name, value } = e.target;
        setProduct({ ...product, [name]: value });

        // Clear error for the field being updated if it's now valid
        const updatedErrors = { ...errors };
        const validationError = productvalidation({ ...product, [name]: value });
        if (!validationError[name]) {
            delete updatedErrors[name];
        }
        setErrors(updatedErrors);
    };

    const handleCategoryChange = (e) => {
        const { name, value } = e.target;
        setProduct({ ...product, [name]: value });

        // Clear error for the category field if it's now valid
        const updatedErrors = { ...errors };
        if (value) {
            delete updatedErrors[name];
        }
        setErrors(updatedErrors);
    };

    const handleFileInput = (e) => {
        const file = e.target.files[0];
        setSelectedPhoto(file);
        setProduct({ ...product, photo: file });

        // Clear error for the file field if it's now valid
        const updatedErrors = { ...errors };
        if (file) {
            delete updatedErrors.photo;
        }
        setErrors(updatedErrors);
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        const validationError = productvalidation({ ...product, [name]: value });
        setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const validationErrors = productvalidation(product);
        setErrors(validationErrors);
        if (Object.keys(validationErrors).length === 0) {
            setSubmitted(true);
        } else {
            setSubmitted(false);
        }
    };

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitted) {
            const formData = new FormData();
            formData.append("pic", selectedPhoto);
            formData.append("pname", product.pname);
            formData.append("price", product.price);
            formData.append("qty", product.qty);
            formData.append("pcat", product.pcat);
            formData.append("sellerId", sellerid);

            axios.post(BASE_URL + "api/products", formData)
                .then(resp => {
                    alert("Product saved successfully");
                    navigate("/myproducts");
                })
                .catch(error => {
                    console.log("Error", error);
                    alert("Error saving product");
                });
        }
    }, [errors, navigate, product.pcat, product.pname, product.price, product.qty, selectedPhoto, sellerid, submitted]);

    return (
        <div className="container">
            <div className="card shadow">
                <div className="card-body">
                    <div className="row">
                        <div className="col-sm-6 mx-auto">
                            <h4 className="text-center p-2">Add Product Form</h4>
                            <form onSubmit={handleSubmit}>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">Product Name</label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="pname"
                                            value={product.pname}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.pname && <small className="text-danger float-right">{errors.pname}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">Category</label>
                                    <div className="col-sm-8">
                                        <select
                                            name="pcat"
                                            value={product.pcat}
                                            onChange={handleCategoryChange}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        >
                                            <option value="">Select Category</option>
                                            {cats.map(x => (
                                                <option key={x.catid} value={x.catid}>{x.catname}</option>
                                            ))}
                                        </select>
                                        {errors.pcat && <small className="text-danger float-right">{errors.pcat}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">Price</label>
                                    <div className="col-sm-8">
                                        <input
                                            type="number"
                                            name="price"
                                            value={product.price}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            min="1" // Minimum value of 1
                                            className="form-control"
                                        />
                                        {errors.price && <small className="text-danger float-right">{errors.price}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">Quantity</label>
                                    <div className="col-sm-8">
                                        <input
                                            type="number"
                                            name="qty"
                                            min={1}
                                            value={product.qty}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className="form-control"
                                        />
                                        {errors.qty && <small className="text-danger float-right">{errors.qty}</small>}
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">Photo</label>
                                    <div className="col-sm-8">
                                        <input
                                            type="file"
                                            
                                            name="photo"
                                            onChange={handleFileInput}
                                            className="form-control-file"
                                        />
                                        {errors.photo && <small className="text-danger float-right">{errors.photo}</small>}
                                    </div>
                                </div>
                                <button className="btn btn-primary float-right">Register Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AddProduct;
