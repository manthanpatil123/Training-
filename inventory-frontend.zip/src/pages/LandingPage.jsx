import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/LandingPage.css"; // Ensure you have styles for the welcome message

function LandingPage() {
  const [isZoomed, setIsZoomed] = useState(false);
  const [isMessageVisible, setIsMessageVisible] = useState(true); // New state
  const navigate = useNavigate();
  const textRef = useRef(null);
  const [scrollPosition, setScrollPosition] = useState(0);

  const handleClick = () => {
    setIsMessageVisible(false); // Hide the welcome message
    setIsZoomed(true);
    setTimeout(() => {
      navigate("/home"); // Navigate to the home page
    }, 1000); // Adjust timing to match CSS transition duration
  };

  useEffect(() => {
    const textElement = textRef.current;
    if (!textElement) return;

    const scrollWidth = textElement.scrollWidth;
    const containerWidth = textElement.parentElement.offsetWidth;
    const totalScrollWidth = scrollWidth + containerWidth;

    const scrollStep = 1;
    const scrollInterval = 20; // Adjust for scrolling speed

    const scroll = () => {
      setScrollPosition((prev) => (prev + scrollStep) % totalScrollWidth);
    };

    const interval = setInterval(scroll, scrollInterval);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="laptop-background">
      <div
        className={`welcome-container ${
          !isMessageVisible ? "hide-message" : ""
        }`}
      >
        <h3
          className="welcome-message"
          style={{
            color: "white",
          }}
          ref={textRef}
        >
          Welcome to InventoryHub!
        </h3>
      </div>
      <div className={`laptop-container ${isZoomed ? "zoomed" : ""}`}>
        <img src="laptop.png" alt="Laptop" className="laptop-image" />
      </div>
      {!isZoomed && (
        <div className="button-container">
          <button onClick={handleClick} className="btn-lets-go">
            Let's Go
          </button>
        </div>
      )}
    </div>
  );
}

export default LandingPage;
