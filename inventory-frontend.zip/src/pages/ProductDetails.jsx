import axios from 'axios';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import { BASE_URL } from '../constants/constants';
import { CART_ACTIONS } from '../store/actions';

function ProductDetails() {
  const { prodid } = useParams();
  const [prod, setProd] = useState({});
  const [qty, setQty] = useState(1);
  const state = useSelector((state) => state);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const checkItem = (prodid) => {
    return state.cart.findIndex((x) => x.prodid === prodid) < 0;
  };

  const addToCart = (item) => {
    if (localStorage.getItem('userid') == null) {
      alert('Please login first to buy product');
      navigate('/login');
    } else if (localStorage.getItem('role') !== 'Customer') {
      alert('Only customers can buy products');
    } else {
      if (qty <= 0) {
        alert('Quantity must be greater than 0');
      } else if (qty > Math.min(prod.qty, 10)) {
        alert(`Quantity exceeds available stock or maximum limit. Maximum allowed is ${Math.min(prod.qty, 10)}`);
      } else if (checkItem(item.prodid)) {
        item.qty = qty;
        dispatch({ type: 'AddItem', payload: item });
        alert('Item added to cart successfully');
      } else {
        alert('Item already in cart');
      }
    }
  };

  useEffect(() => {
    axios
      .get(BASE_URL + 'api/products/' + prodid)
      .then((resp) => setProd(resp.data))
      .catch((err) => err.response.data);
  }, [prodid]);

  return (
    <div className='container'>
      <div className='row'>
        <div className='col-sm-4' key={prod?.prodid}>
          <img
            alt="Product"
            style={{ width: '100%', height: '450px', marginBottom: '10px' }}
            src={BASE_URL + 'images/' + prod?.photo}
            className='img-thumbnail mt-3'
          />
        </div>
        <div className='col-sm-5'>
          <div
            className='card bg-transparent mt-3'
            style={{ boxShadow: '0 0 3px 3px white' }}
          >
            <div className='card-body'>
              <h4>{prod?.pname}</h4>
              <h5>Category: {prod?.category?.catname}</h5>
              <h5>Seller: {prod?.seller?.name}</h5>
              <h5>Price: &#8377; {new Intl.NumberFormat('en-IN').format(prod?.price)}</h5>
              <h6>{prod?.descr?.split("\n").map((item, idx) =>
                <span key={idx}>{item}<br /></span>
              )}</h6>
              {prod.qty > 0 ? (
                <>
                  <input
                    type='number'
                    value={qty}
                    min={1}
                    max={Math.min(prod?.qty, 10)}
                    className='form-control'
                    onChange={(e) => {
                      let value = Math.floor(Number(e.target.value));
                      if (value > 10) value = 10; // Limit input to 10
                      setQty(value > 0 ? value : 1);
                    }}
                  />
                  <small className='text-muted'>
                    Maximum Quantity Allowed: {Math.min(prod?.qty, 10)}
                  </small>
                  <br />
                  <small className='text-muted'>
                    Available Stock: {prod?.qty}
                  </small>
                  <button
                    onClick={() => addToCart(prod)}
                    className='btn btn-primary btn-block mt-3'
                  >
                    Add to Cart
                  </button>
                </>
              ) : (
                <h6 className='text-danger'>Oops, We’re Out of Stock!</h6>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
