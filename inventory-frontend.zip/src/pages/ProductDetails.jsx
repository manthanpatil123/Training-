import axios from 'axios'
import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { useParams } from 'react-router-dom'
import { BASE_URL } from '../constants/constants'
import { CART_ACTIONS } from '../store/actions'

function ProductDetails({ x }) {
  const { prodid } = useParams()
  const [prod, setprod] = useState({})
  const [qty, setQty] = useState(1)
  const state = useSelector((state) => state)
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const checkItem = (prodid) => {
    return state.cart.findIndex((x) => x.prodid === prodid) < 0
  }

  const addToCart = (item) => {
    if (localStorage.getItem('userid') == null) {
      alert('Please login first to buy product')
      navigate('/login')
    } else if (localStorage.getItem('role') !== 'Customer') {
      alert('Only customer can buy product')
    } else {
      if (checkItem(item.prodid)) {
        item.qty=qty         
        dispatch({type:'AddItem',payload:item})
        alert("Item added to cart successfully")
        
      } else {
        alert('Item already in cart')
      }
    }
  }

  useEffect(() => {
    axios
      .get(BASE_URL+'api/products/' + prodid)
      .then((resp) => setprod(resp.data))
      .catch((err) => err.response.data)
  }, [])
  return (
    <div className='container'>
      <div className='row'>
        <div className='col-sm-4' key={prod?.prodid}>
          <img
          alt="Product"
            style={{ width: '100%', height: '450px', marginBottom: '10px' }}
            src={BASE_URL +'images/'+ prod?.photo}
            className='img-thumnail mt-3'
          />
        </div>
        <div className='col-sm-5'>
          <div
            className='card bg-transparent mt-3'
            style={{ boxShadow: '0 0 3px 3px white' }}
          >
            <div className='card-body'>
              <h4>{prod?.pname}</h4>
              <h5>Category: {prod?.category?.catname}</h5>
              <h5>Seller: {prod?.seller?.name}</h5>
              <h5>Price: &#8377; {prod?.price}</h5>
              <h6>{prod?.descr?.split("\n").map((item,idx)=>
                <span key={idx}>{item}<br/></span>
              )}</h6>
              {prod.qty > 0 ? (
                <>
              <input
                type='number'
                value={qty}
                min={1}
                max={prod?.qty}
                className='form-control'
                onChange={(e) => setQty(e.target.value)}
              />
              
              <button
                onClick={(e) => addToCart(prod)}
                className='btn btn-primary btn-block mt-3'
              >
                Add to Cart
              </button>
              </>
              ):<h6 className='text-danger'>Item not available</h6>}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProductDetails
