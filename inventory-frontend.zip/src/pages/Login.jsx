import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import loginvalidation from "../validations/loginvalidation";
import { BASE_URL } from "../constants/constants";
import { LOGIN_ACTIONS } from "../store/actions";

function Login() {
    const dispatch = useDispatch();
    const [user, setUser] = useState({
        userid: "",
        pwd: "",
        role: ""
    });
    const [touched, setTouched] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const [errors, setErrors] = useState({});
    const [errmsg, setErrmsg] = useState();
    const history = useNavigate();

    const handleInput = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });

        // Clear the error for the field being updated if it's now valid
        const updatedErrors = { ...errors };
        const validationError = loginvalidation({ ...user, [name]: value });
        if (!validationError[name]) {
            delete updatedErrors[name];
        }
        setErrors(updatedErrors);
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;

        // Mark the field as touched
        setTouched({ ...touched, [name]: true });

        // Validate the field
        const validationError = loginvalidation({ ...user, [name]: value });
        setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const validationErrors = loginvalidation(user);
        setErrors(validationErrors);

        // Set submitted only if there are no validation errors
        if (Object.keys(validationErrors).length === 0) {
            setSubmitted(true);
        } else {
            setSubmitted(false);
        }
    };

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitted) {
            axios.post(`${BASE_URL}api/users/validate`, user)
                .then((resp) => {
                    const result = resp.data;
                    localStorage.setItem("userid", result.userid);
                    localStorage.setItem("uname", result.name);
                    localStorage.setItem("role", result.role);
                    localStorage.setItem("user", JSON.stringify(result));
                    dispatch({ type: LOGIN_ACTIONS.IS_LOGGED_IN });

                    // Navigate based on user role
                    if (result.role === "Seller") {
                        history("/sprofile");
                    } else if (result.role === "Admin") {
                        history("/category");
                    } else {
                        history("/");
                    }
                })
                .catch((error) => {
                    console.log("Error", error);
                    setErrmsg("Invalid username or password..!!");
                })
                .finally(() => {
                    setSubmitted(false); // Reset submitted state after login attempt
                });
        }
    }, [dispatch, errors, history, submitted, user]);

    return (
        <div className="container" style={{ width: "60%" }}>
            <div className="card shadow mt-3">
                <div className="card-body">
                    <div className="row">
                        <div className="col-sm-8 mx-auto">
                            <h4 className="text-center p-2">Login Form</h4>
                            <form onSubmit={handleSubmit}>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: "red" }}>*</span>User ID
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="userid"
                                            value={user.userid}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.userid && errors.userid ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.userid && errors.userid && <small className="text-danger float-left">{errors.userid}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: "red" }}>*</span>Password
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="password"
                                            name="pwd"
                                            value={user.pwd}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.pwd && errors.pwd ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.pwd && errors.pwd && <small className="text-danger float-left">{errors.pwd}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: "red" }}>*</span>Role
                                    </label>
                                    <div className="col-sm-8">
                                        <select
                                            name="role"
                                            value={user.role}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.role && errors.role ? 'is-invalid' : ''}`}
                                        >
                                            <option value="">Select Role</option>
                                            <option>Admin</option>
                                            <option>Seller</option>
                                            <option>Customer</option>
                                        </select>
                                        <div className="error-container">
                                            {touched.role && errors.role && <small className="text-danger float-left">{errors.role}</small>}
                                        </div>
                                    </div>
                                </div>
                                <button className="btn btn-primary float-right" disabled={Object.keys(errors).length > 0}>Login Now</button>
                            </form>
                            <div className="clearfix"></div>
                            {errmsg && <p className="alert alert-danger mt-4 text-center font-weight-bold">{errmsg}</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;
