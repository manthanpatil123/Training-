import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { BASE_URL } from "../constants/constants";
import { CART_ACTIONS } from "../store/actions";
import "../CSS/ViewCart.css"; // Import custom CSS for styling

function ViewCart() {
  const state = useSelector((state) => state);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [address, setAddress] = useState({
    city: "",
    state: "",
    zip: "",
    country: "",
  });
  const [payment, setPayment] = useState({
    cardno: "",
    nameoncard: "",
    cvv: "",
    amount: state.cart.reduce((a, b) => a + b.price * b.qty, 0),
  });

  const [touched, setTouched] = useState({
    city: false,
    state: false,
    zip: false,
    country: false,
    cardno: false,
    nameoncard: false,
    cvv: false,
  });

  const [errors, setErrors] = useState({
    city: "",
    state: "",
    zip: "",
    country: "",
    cardno: "",
    nameoncard: "",
    cvv: "",
  });

  const [isLocked, setIsLocked] = useState(false);

  const validateField = (name, value) => {
    let error = "";
    const trimmedValue = String(value).trim(); // Ensure value is a string

    // Check for required fields first
    if (!trimmedValue) {
      if (name === "cardno") {
        error = "Card No is required.";
      } else if (name === "nameoncard") {
        error = "Name on Card is required.";
      } else {
        error = `${name.charAt(0).toUpperCase() + name.slice(1)} is required.`;
      }
    } else {
      // Apply specific field validations
      if (
        name === "city" ||
        name === "state" ||
        name === "country" ||
        name === "nameoncard"
      ) {
        if (!/^[a-zA-Z\s]+$/.test(trimmedValue)) {
          error = `${
            name.charAt(0).toUpperCase() + name.slice(1)
          } can only contain letters and spaces.`;
        } else if (trimmedValue.length > 50) {
          error = `${
            name.charAt(0).toUpperCase() + name.slice(1)
          } must be less than 50 characters.`;
        }
        if (name === "nameoncard" && trimmedValue.length < 3) {
          error = "Are you sure you entered your name correctly?";
        }
      }

      if (name === "zip") {
        if (!/^\d{6}$/.test(trimmedValue)) {
          error = "Zip code must be 6 digits.";
        }
      }

      if (name === "cardno") {
        if (!/^\d{16}$/.test(trimmedValue)) {
          error = "Card number must be 16 digits.";
        }
      }

      if (name === "cvv") {
        if (!/^\d{3}$/.test(trimmedValue)) {
          error = "CVV must be 3 digits.";
        }
      }
    }

    setErrors((prevErrors) => ({ ...prevErrors, [name]: error }));
  };

  const handleInput = (e) => {
    const { name, value } = e.target;
    setAddress((prevAddress) => ({ ...prevAddress, [name]: value }));
    validateField(name, value);
  };

  const handlePaymentInput = (e) => {
    const { name, value } = e.target;
    setPayment((prevPayment) => ({ ...prevPayment, [name]: value }));
    validateField(name, value);
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const trimmedValue = value.trim().replace(/\s+/g, " ");

    if (address.hasOwnProperty(name)) {
      setAddress((prevAddress) => ({ ...prevAddress, [name]: trimmedValue }));
    } else if (payment.hasOwnProperty(name)) {
      setPayment((prevPayment) => ({ ...prevPayment, [name]: trimmedValue }));
    }

    setTouched((prevTouched) => ({ ...prevTouched, [name]: true }));
    validateField(name, trimmedValue);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Set touched state for all fields on submit
    setTouched({
      city: true,
      state: true,
      zip: true,
      country: true,
      cardno: true,
      nameoncard: true,
      cvv: true,
    });

    // Validate all fields
    Object.keys(address).forEach((key) => validateField(key, address[key]));
    Object.keys(payment).forEach((key) => validateField(key, payment[key]));

    if (Object.values(errors).some((error) => error !== "")) {
      console.log("Form has errors");
      setIsLocked(true);
      return;
    }

    setIsLocked(false);
    const data = {
      cart: state.cart,
      payment: payment,
      address: address,
      customerid: localStorage.getItem("userid"),
    };

    axios
      .post(BASE_URL + "api/orders", data)
      .then((resp) => {
        console.log(resp);
        dispatch({ type: CART_ACTIONS.CLEAR_CART });
        navigate("/myorders");
      })
      .catch((error) => {
        console.error("Error placing order:", error);
      });
  };

  useEffect(() => {
    const amount = state.cart.reduce((a, b) => a + b.price * b.qty, 0);
    setPayment((prevPayment) => ({ ...prevPayment, amount }));
    console.log("Amount =>", new Intl.NumberFormat("en-IN").format(amount));
  }, [state.cart]);

  const deleteItem = (item) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      console.log("Dispatching REMOVE_ITEM with ID:", item.prodid);
      dispatch({ type: CART_ACTIONS.REMOVE_ITEM, payload: item.prodid });
    }
  };

  const totalAmount = state.cart.reduce((a, b) => a + b.price * b.qty, 0);

  return (
    <div className="container-fluid">
      {state.cart.length > 0 ? (
        <div className="row justify-content-center align-items-start">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header">
                <h4 className="p-2">Cart View</h4>
              </div>
              <div className="card-body">
                <table className="table table-bordered table-striped">
                  <thead className="table-dark">
                    <tr>
                      <th>Product Name</th>
                      <th>Price</th>
                      <th>Qty</th>
                      <th>Amount</th>
                      <th>Cancel</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.cart.map((item) => (
                      <tr key={item.prodid}>
                        <td style={{ textAlign: "center" }}>
                          {item.pname}
                          <br />
                          <img
                            alt={item.pname}
                            src={BASE_URL + "images/" + item.photo}
                            width="100"
                            height="130"
                          />
                        </td>
                        <td>
                          &#8377;{" "}
                          {new Intl.NumberFormat("en-IN").format(item.price)}
                        </td>
                        <td>{item.qty}</td>
                        <td>
                          &#8377;{" "}
                          {new Intl.NumberFormat("en-IN").format(
                            item.qty * item.price
                          )}
                        </td>
                        <td>
                          <button
                            onClick={() => deleteItem(item)}
                            className="btn btn-danger btn-sm"
                          >
                            &times;
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <th colSpan="4">Total Amount</th>
                      <th>
                        &#8377;{" "}
                        {new Intl.NumberFormat("en-IN").format(totalAmount)}
                      </th>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>

          {/* Address & Payment Information Section */}
          <div className="col-md-6">
            <div className="card">
              <div className="card-header">
                <h4 className="p-2">Address & Payment Information</h4>
              </div>
              <div className="card-body">
                <form className="viewcart-from" onSubmit={handleSubmit}>
                  <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">
                      City <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="city"
                        required
                        value={address.city}
                        onChange={handleInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.city && errors.city ? "is-invalid" : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.city && errors.city && (
                          <div className="invalid-feedback">{errors.city}</div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">
                      State <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="state"
                        required
                        value={address.state}
                        onChange={handleInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.state && errors.state ? "is-invalid" : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.state && errors.state && (
                          <div className="invalid-feedback">{errors.state}</div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">
                      Zip Code <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="zip"
                        required
                        value={address.zip}
                        onChange={handleInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.zip && errors.zip ? "is-invalid" : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.zip && errors.zip && (
                          <div className="invalid-feedback">{errors.zip}</div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">
                      Country <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="country"
                        required
                        value={address.country}
                        onChange={handleInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.country && errors.country ? "is-invalid" : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.country && errors.country && (
                          <div className="invalid-feedback">
                            {errors.country}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">
                      Card No <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="cardno"
                        required
                        value={payment.cardno}
                        onChange={handlePaymentInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.cardno && errors.cardno ? "is-invalid" : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.cardno && errors.cardno && (
                          <div className="invalid-feedback">
                            {errors.cardno}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group form-row">
                    <label className="col-sm-6 form-control-label">
                      Name on Card <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="nameoncard"
                        required
                        value={payment.nameoncard}
                        onChange={handlePaymentInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.nameoncard && errors.nameoncard
                            ? "is-invalid"
                            : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.nameoncard && errors.nameoncard && (
                          <div className="invalid-feedback">
                            {errors.nameoncard}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">
                      CVV <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="col-sm-8">
                      <input
                        type="text"
                        name="cvv"
                        required
                        value={payment.cvv}
                        onChange={handlePaymentInput}
                        onBlur={handleBlur}
                        className={`form-control ${
                          touched.cvv && errors.cvv ? "is-invalid" : ""
                        }`}
                      />
                      <div className="viewcart-error-container">
                        {touched.cvv && errors.cvv && (
                          <div className="invalid-feedback">{errors.cvv}</div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group text-center">
                    <button
                      type="submit"
                      className="viewcart-btn"
                      disabled={isLocked}
                    >
                      Submit
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="alert alert-info text-center">Your cart is empty.</div>
      )}
    </div>
  );
}

export default ViewCart;
