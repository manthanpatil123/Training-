import axios from "axios";
import { useEffect, useState } from "react";
import Moment from "react-moment";
import { BASE_URL } from "../constants/constants";
import { useNavigate } from "react-router-dom";

function SellerOrders(){
    const [orders,setOrders]=useState([])
    const [show,setShow]=useState(false)
    const [details,setDetails]=useState([])
    const sellerid=localStorage.getItem("userid");
    const history = useNavigate();

    useEffect(()=>{
        axios.get(BASE_URL+"api/orders/sellers?sellerid="+sellerid)
        .then(resp=>{
            console.log(resp.data)
            setOrders(resp.data)
        })
    },[]);

    const showDetails=(orderid)=>{
        const data = orders.filter(x=>x.orderid === orderid)[0].orderdetails;
        setDetails(data);
        setShow(true)
    }

    const handleConfirm = (id)=>{
        axios.get(BASE_URL+"api/orders/confirm/"+id)
        .then(resp=>{
            alert(resp.data.message);
            history("/myproducts");
        })
    }
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-sm-7">
                <h4 className="p-2 text-center">Seller Orders</h4>
                <table className="table table-bordered table-striped table-light table-hover">
                    <thead className="table-dark">
                        <tr>
                            <th>Id</th>
                            <th>Order Date</th>
                            <th>Amount</th>
                            <th>Customer</th>
                            <th>Action</th>                       
                        </tr>
                    </thead>
                    <tbody>
                        {orders.map(x=>(
                            <tr key={x.orderid}>
                                <td>{x.orderid}</td>
                                <td><Moment format="ddd, DD-MMM-YYYY">{x.orderDate}</Moment></td>
                                <td>&#8377; {x.payment.amount}</td>
                                <td>{x.customer.name}</td>
                                <td><button onClick={e=>showDetails(x.orderid)} className="btn btn-primary btn-sm">Show Details</button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>  
                </div>
                <div className="col-sm-5">
                    {show ? <>
                    <h4 className="p-2 text-center">Order Details</h4>
                    <table className="table table-bordered table-striped table-light table-hover">
                        <thead className="table-dark">
                            <tr>
                                <th>Id</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {details.map(x => (
                                <tr key={x.id}>
                                    <td>{x.id}</td>
                                    <td><img className="mr-2 float-left" alt="product" src={BASE_URL+"images/"+x.prod.photo} width="60" height="60" />
                                    {x.prod.pname}<br/>
                                    {x.prod.cat}
                                    </td>
                                    <td>{x.prod.price}</td>
                                    <td>{x.qty}</td>
                                    <td>
                                        {x.status === "Pending" ?(
                                        <button className="btn btn-success btn-sm" onClick={e=>handleConfirm(x.id)}>Confirm</button>
                                    ):x.status}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    </> : ''}
                </div>
            </div>                
                              
        </div>                    
    )
}

export default SellerOrders;