import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import productvalidation from "../validations/productvalidation";
import { BASE_URL } from "../constants/constants";

function EditProduct() {
  const sellerid = localStorage.getItem("userid");
  const { prodid } = useParams();
  const [product, setProduct] = useState({
    prodid: prodid,
    pname: "",
    pcat: "",
    price: "",
    qty: "",
    descr: "",
    sellerId: sellerid,
  });

  const [errors, setErrors] = useState({});
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const history = useNavigate();
  const [cats, setcats] = useState([]);
  const handleInput = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrors(productvalidation(product));
    setSubmitted(true);
  };

  const handleFileInput = (e) => {
    const file = e.target.files[0];
    setSelectedPhoto(file);
    setProduct({ ...product, photo: file });

    // Clear error for the file field if it's now valid
    const updatedErrors = { ...errors };
    if (file) {
        delete updatedErrors.photo;
    }
    setErrors(updatedErrors);
};

  useEffect(() => {
    axios
      .get(BASE_URL+"api/category")
      .then((resp) => setcats(resp.data));
    axios.get(BASE_URL+"api/products/" + prodid).then((resp) => {
      console.log("product", resp.data);
      setProduct({
        pname: resp.data.pname,
        pcat: resp.data.pcat,
        price: resp.data.price,
        qty: resp.data.qty,
        photo: resp.data.photo,
        descr: resp.data.descr,
      });
    });
  }, []);

  useEffect(() => {
    console.log(errors);
    if (Object.keys(errors).length === 0 && submitted) {
      console.log(product);
      const formData = new FormData();
      formData.append("pic", selectedPhoto);
      formData.append("pname", product.pname);
      formData.append("price", product.price);
      formData.append("qty", product.qty);
      formData.append("pcat", product.pcat);
      formData.append("sellerId", product.sellerId);
      axios
        .put(BASE_URL+"api/products/" + prodid, formData)
        .then((resp) => {
          let result = resp.data;
          console.log(result);
          alert("Product saved successfully");
          history("/myproducts");
        })
        .catch((error) => {
          console.log("Error", error);
          alert("Error saving product");
        });
    }
  }, [errors]);
  return (
    <div className="container-fluid">
      <div className="row">
        
        <div className="col-sm-3 offset-1">
          <img
            alt="Product"
            width="300"
            src={BASE_URL+"images/" + product.photo}
          />
        </div>

        <div className="col-sm-5">
          <div className="card shadow">
            <div className="card-body">
              <h4 className="text-center p-2">Edit Product</h4>
              <form onSubmit={handleSubmit}>
                <div className="form-group form-row">
                  <label className="col-sm-4 form-control-label">
                    Product Name
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      name="pname"
                      value={product.pname}
                      onChange={handleInput}
                      className="form-control"
                    />
                    {errors.pname && (
                      <small className="text-danger float-right">
                        {errors.pname}
                      </small>
                    )}
                  </div>
                </div>
                <div className="form-group form-row">
                  <label className="col-sm-4 form-control-label">
                    Category
                  </label>
                  <div className="col-sm-8">
                    <select
                      name="pcat"
                      value={product.pcat}
                      onChange={handleInput}
                      className="form-control"
                    >
                      <option value="">Select Category</option>
                      {cats.map((x) => (
                        <option key={x.catid} value={x.catid}>
                          {x.catname}
                        </option>
                      ))}
                    </select>
                    {errors.pcat && (
                      <small className="text-danger float-right">
                        {errors.pcat}
                      </small>
                    )}
                  </div>
                </div>
                
                <div className="form-group form-row">
                  <label className="col-sm-4 form-control-label">Price</label>
                  <div className="col-sm-8">
                    <input
                      type="number"
                      name="price"
                      value={product.price}
                      onChange={handleInput}
                      className="form-control"
                    />
                    {errors.price && (
                      <small className="text-danger float-right">
                        {errors.price}
                      </small>
                    )}
                  </div>
                </div>
                <div className="form-group form-row">
                  <label className="col-sm-4 form-control-label">Quantity</label>
                  <div className="col-sm-8">
                    <input
                      type="number"
                      name="qty"
                      min={1}
                      value={product.qty}
                      onChange={handleInput}
                      className="form-control"
                    />
                    {errors.qty && (
                      <small className="text-danger float-right">
                        {errors.qty}
                      </small>
                    )}
                  </div>
                </div>

                <div className="form-group form-row">
                    <label className="col-sm-4 form-control-label">Photo</label>
                    <div className="col-sm-8">
                        <input
                            type="file"
                            
                            name="photo"
                            onChange={handleFileInput}
                            className="form-control-file"
                        />
                        {errors.photo && <small className="text-danger float-right">{errors.photo}</small>}
                    </div>
                </div>
                
                

                <button className="btn btn-primary float-right">
                  Update Product
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditProduct;
