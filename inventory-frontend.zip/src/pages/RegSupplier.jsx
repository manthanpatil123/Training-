import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import uservalidation from "../validations/uservalidation";
import { BASE_URL } from "../constants/constants";

function RegSupplier() {
    const [user, setUser] = useState({
        name: "",
        city: "",
        userid: "",
        pwd: "",
        cpwd: "",
        phone: "",
        gender: "",
        role: "Seller"
    });
    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const navigate = useNavigate();

    const handleInput = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });

        // Clear error for the field being updated if it's now valid
        const updatedErrors = { ...errors };
        const validationError = uservalidation({ ...user, [name]: value });
        if (!validationError[name]) {
            delete updatedErrors[name];
        }
        setErrors(updatedErrors);
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;

        // Trim leading and trailing spaces, replace multiple spaces with a single space
        const trimmedValue = value.trim().replace(/\s+/g, ' ');

        setUser({ ...user, [name]: trimmedValue }); // Update the state with cleaned-up value
        setTouched({ ...touched, [name]: true }); // Mark field as touched

        const validationError = uservalidation({ ...user, [name]: trimmedValue });
        setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));

        if (name === "userid") {
            axios.get(`${BASE_URL}api/users/verify?userid=${trimmedValue}`)
                .then(resp => {
                    if (resp.data) {
                        setErrors((prevErrors) => ({ ...prevErrors, "userid": "Userid already exists" }));
                    }
                });
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Mark all fields as touched
        const allFieldsTouched = Object.keys(user).reduce((acc, key) => {
            acc[key] = true;
            return acc;
        }, {});
        setTouched(allFieldsTouched);

        // Perform validation
        const validationErrors = uservalidation(user);
        if (!user.gender) {
            validationErrors.gender = "Gender is required";
        }
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length === 0) {
            setSubmitted(true);
        } else {
            setSubmitted(false);
        }
    };

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitted) {
            axios.post(`${BASE_URL}api/users/register`, user)
                .then((resp) => {
                    alert("Seller registered successfully");
                    navigate("/login");
                })
                .catch(() => {
                    alert("Entered User Name is Not Available");
                })
                .finally(() => {
                    setSubmitted(false); // Reset submitted state after registration attempt
                });
        }
    }, [errors, submitted, user, navigate]);

    return (
        <div className="container">
            <div className="card shadow mt-3">
                <div className="card-body">
                    <div className="row">
                        <div className="col-sm-6 mx-auto">
                            <h4 className="text-center p-2">Seller Registration</h4><div><br></br></div>
                            <form onSubmit={handleSubmit}>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Name
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="name"
                                            value={user.name}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            maxLength="50" // Set an appropriate length limit
                                            className={`form-control ${touched.name && !user.name ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.name && errors.name && <small className="text-danger">{errors.name}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>City
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="city"
                                            value={user.city}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            maxLength="50" // Set an appropriate length limit
                                            className={`form-control ${touched.city && !user.city ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.city && errors.city && <small className="text-danger">{errors.city}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Gender
                                    </label>
                                    <div className="col-sm-8">
                                        <select
                                            name="gender"
                                            value={user.gender}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.gender && !user.gender ? 'is-invalid' : ''}`}
                                        >
                                            <option value="">Select Gender</option>
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>
                                        <div className="error-container">
                                            {touched.gender && errors.gender && <small className="text-danger">{errors.gender}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>User ID
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            name="userid"
                                            value={user.userid}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            maxLength="30" // Set an appropriate length limit
                                            className={`form-control ${touched.userid && !user.userid ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.userid && errors.userid && <small className="text-danger">{errors.userid}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Phone
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="text"
                                            maxLength="10"
                                            name="phone"
                                            value={user.phone}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.phone && !user.phone ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.phone && errors.phone && <small className="text-danger">{errors.phone}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Password
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="password"
                                            name="pwd"
                                            value={user.pwd}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.pwd && !user.pwd ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.pwd && errors.pwd && <small className="text-danger">{errors.pwd}</small>}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group form-row">
                                    <label className="col-sm-4 form-control-label">
                                        <span style={{ color: 'red' }}>*</span>Confirm Password
                                    </label>
                                    <div className="col-sm-8">
                                        <input
                                            type="password"
                                            name="cpwd"
                                            value={user.cpwd}
                                            onChange={handleInput}
                                            onBlur={handleBlur}
                                            className={`form-control ${touched.cpwd && !user.cpwd ? 'is-invalid' : ''}`}
                                        />
                                        <div className="error-container">
                                            {touched.cpwd && errors.cpwd && <small className="text-danger">{errors.cpwd}</small>}
                                        </div>
                                    </div>
                                </div>
                                <button className="btn btn-primary float-right">Register Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default RegSupplier;
