import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import uservalidation from "../validations/uservalidation";
import { BASE_URL } from "../constants/constants";
import "../CSS/Register.css"; // Import custom CSS for styling

function RegSupplier() {
  const [user, setUser] = useState({
    name: "",
    city: "",
    userid: "",
    pwd: "",
    cpwd: "",
    phone: "",
    gender: "",
    role: "Seller",
  });
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setUser((prev) => ({ ...prev, [name]: value }));

    const validationErrors = uservalidation({ ...user, [name]: value });
    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      if (!validationErrors[name]) {
        delete updatedErrors[name];
      }
      return updatedErrors;
    });
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const trimmedValue = value.trim().replace(/\s+/g, " ");

    setUser((prev) => ({ ...prev, [name]: trimmedValue }));
    setTouched((prev) => ({ ...prev, [name]: true }));

    const validationError = uservalidation({ ...user, [name]: trimmedValue });
    setErrors((prevErrors) => ({ ...prevErrors, ...validationError }));

    if (name === "userid") {
      axios
        .get(`${BASE_URL}api/users/verify?userid=${trimmedValue}`)
        .then((resp) => {
          if (resp.data) {
            setErrors((prevErrors) => ({
              ...prevErrors,
              userid: "Userid already exists",
            }));
          }
        });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const allFieldsTouched = Object.keys(user).reduce((acc, key) => {
      acc[key] = true;
      return acc;
    }, {});
    setTouched(allFieldsTouched);

    const validationErrors = uservalidation(user);
    if (!user.gender) {
      validationErrors.gender = "Gender is required";
    }
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
    } else {
      setSubmitted(false);
    }
  };

  useEffect(() => {
    if (Object.keys(errors).length === 0 && submitted) {
      axios
        .post(`${BASE_URL}api/users/register`, user)
        .then((resp) => {
          alert("Seller registered successfully");
          navigate("/login");
        })
        .catch(() => {
          alert("Entered User Name is Not Available");
        })
        .finally(() => {
          setSubmitted(false);
        });
    }
  }, [errors, submitted, user, navigate]);

  return (
    <div className="regsupplier-container">
      <div className="regsupplier-card">
        <div className="reg-image">
          {/* Add any additional image styling or content here if needed */}
        </div>
        <div className="regsupplier-card-body">
          <div className="logo-container">
            <img
              src="../minilogo.png"
              alt="Logo"
              className="regsupplier-logo"
            />
          </div>
          <h4 className="login-title">Seller Registration</h4>
          <form onSubmit={handleSubmit}>
            <div className="seller-form-group">
              <label htmlFor="name">
                Name<span className="required">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={user.name}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.name && errors.name ? "is-invalid" : ""
                }`}
              />
              <div className="regseller-error-container">
                <div className="regseller-">
                  {touched.name && errors.name && (
                    <small className="reg-text-danger">{errors.name}</small>
                  )}
                </div>
              </div>
            </div>
            <div className="seller-form-group">
              <label htmlFor="city">
                City<span className="required">*</span>
              </label>
              <input
                type="text"
                id="city"
                name="city"
                value={user.city}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.city && errors.city ? "is-invalid" : ""
                }`}
              />
              <div className="regseller-error-container">
                <div className="regseller-">
                  {touched.city && errors.city && (
                    <small className="reg-text-danger">{errors.city}</small>
                  )}
                </div>
              </div>
            </div>
            <div className="seller-form-group">
              <label htmlFor="gender">
                Gender<span className="required">*</span>
              </label>
              <select
                id="gender"
                name="gender"
                value={user.gender}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.gender && errors.gender ? "is-invalid" : ""
                }`}
              >
                <option value="">Select Gender</option>
                <option>Male</option>
                <option>Female</option>
              </select>
              <div className="regseller-error-container">
                {touched.gender && errors.gender && (
                  <small className="reg-text-danger">{errors.gender}</small>
                )}
              </div>
            </div>
            <div className="seller-form-group">
              <label htmlFor="userid">
                User ID<span className="required">*</span>
              </label>
              <input
                type="text"
                id="userid"
                name="userid"
                value={user.userid}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.userid && errors.userid ? "is-invalid" : ""
                }`}
              />
              <div className="regseller-error-container">
                <div className="regseller-">
                  {touched.userid && errors.userid && (
                    <small className="reg-text-danger">{errors.userid}</small>
                  )}
                </div>
              </div>
            </div>
            <div className="seller-form-group">
              <label htmlFor="phone">
                Phone<span className="required">*</span>
              </label>
              <input
                type="text"
                id="phone"
                name="phone"
                maxLength="10"
                value={user.phone}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.phone && errors.phone ? "is-invalid" : ""
                }`}
              />
              <div className="regseller-error-container">
                <div className="regseller-">
                  {touched.phone && errors.phone && (
                    <small className="reg-text-danger">{errors.phone}</small>
                  )}
                </div>
              </div>
            </div>
            <div className="seller-form-group">
              <label htmlFor="pwd">
                Password<span className="required">*</span>
              </label>
              <input
                type="password"
                id="pwd"
                name="pwd"
                value={user.pwd}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.pwd && errors.pwd ? "is-invalid" : ""
                }`}
              />
              <div className="regseller-error-container">
                <div className="regseller-">
                  {touched.pwd && errors.pwd && (
                    <small className="reg-text-danger">{errors.pwd}</small>
                  )}
                </div>
              </div>
            </div>
            <div className="seller-form-group">
              <label htmlFor="cpwd">
                Confirm Password<span className="required">*</span>
              </label>
              <input
                type="password"
                id="cpwd"
                name="cpwd"
                value={user.cpwd}
                onChange={handleInput}
                onBlur={handleBlur}
                className={`form-control ${
                  touched.cpwd && errors.cpwd ? "is-invalid" : ""
                }`}
              />
              <div className="regseller-error-container">
                <div className="regseller-">
                  {touched.cpwd && errors.cpwd && (
                    <small className="reg-text-danger">{errors.cpwd}</small>
                  )}
                </div>
              </div>
            </div>
            <button
              type="submit"
              className="seller-btn"
              disabled={Object.keys(errors).length > 0}
            >
              Register Now
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default RegSupplier;
