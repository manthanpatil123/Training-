const USER_ID_REGEX = /^[a-zA-Z0-9._]{6,15}$/;
const USER_ID_START_END_REGEX = /^[._]|[._]$/;
const USER_ID_CONSECUTIVE_REGEX = /([._])\1/;
const PHONE_REGEX = /^\d{10}$/;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const uservalidation = (values) => {
    let errors = {};

    // Trim whitespace and normalize space in name
    values.name = values.name ? values.name.trim().replace(/\s+/g, ' ') : '';
    values.city = values.city ? values.city.trim() : '';
    values.userid = values.userid ? values.userid.trim() : '';
    values.phone = values.phone ? values.phone.trim() : '';
    values.pwd = values.pwd ? values.pwd.trim() : '';
    values.cpwd = values.cpwd ? values.cpwd.trim() : '';

    if (!values.name) {
        errors.name = "Name is required";
    } else if (values.name.length < 3) {
        errors.name = "Are you sure you entered your name correctly?";
    }

    if (!values.city) {
        errors.city = "City is required";
    }

    if (!values.userid) {
        errors.userid = "User ID is required";
    } else if (!USER_ID_REGEX.test(values.userid)) {
        errors.userid = "User ID must be 6-15 characters, alphanumeric";
    } else if (USER_ID_START_END_REGEX.test(values.userid)) {
        errors.userid = "User ID cannot start or end with _ or .";
    } else if (USER_ID_CONSECUTIVE_REGEX.test(values.userid)) {
        errors.userid = "User ID cannot have consecutive _ or .";
    }

    if (!values.phone) {
        errors.phone = "Phone is required";
    } else if (!PHONE_REGEX.test(values.phone)) {
        errors.phone = "Phone must be 10 digits";
    }
    
    if (!values.gender) {
        errors.gender = "Gender is required";
    }

    if (!values.pwd) {
        errors.pwd = "Password is required";
    } else if (!PASSWORD_REGEX.test(values.pwd)) {
        errors.pwd = "Password must be at least 8 characters long, include one uppercase letter, one lowercase letter, one digit, and one special character";
    }

    if (!values.cpwd) {
        errors.cpwd = "Confirm Password is required";
    } else if (values.pwd && values.cpwd && values.pwd !== values.cpwd) {
        errors.cpwd = "Passwords do not match";
    }

    return errors;
}

export default uservalidation;
