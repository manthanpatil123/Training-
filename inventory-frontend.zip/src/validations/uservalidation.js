const USER_ID_REGEX = /^[a-zA-Z](?=.*\d)[a-zA-Z\d._]{5,14}$/; // Regex for general User ID validation
const USER_ID_START_END_REGEX = /^[._]|[._]$/; // Regex to check if User ID starts or ends with a period or underscore
const USER_ID_LETTER_REGEX = /[a-zA-Z]/; // Check for at least one letter
const USER_ID_ALLOWED_CHARACTERS_REGEX = /^[a-zA-Z\d._]+$/; // Allow only letters, numbers, underscores, and periods
const USER_ID_DIGIT_REGEX = /\d/; // Check for at least one digit
const USER_ID_CONSECUTIVE_REGEX = /([.])\1/; // Regex to check for consecutive periods
const USER_ID_SPACE_REGEX = /\s/; // Regex to check for spaces in User ID
const PHONE_REGEX = /^\d{10}$/; // Regex for phone number
const PASSWORD_LENGTH_REGEX = /^.{8,15}$/; // Regex for password length between 8 and 15 characters
const PASSWORD_UPPERCASE_REGEX = /[A-Z]/; // Regex to check for at least one uppercase letter
const PASSWORD_LOWERCASE_REGEX = /[a-z]/; // Regex to check for at least one lowercase letter
const PASSWORD_DIGIT_REGEX = /\d/; // Regex to check for at least one digit
const PASSWORD_SPECIAL_REGEX = /[@$!%*?&]/; // Regex to check for at least one special character
const NAME_CITY_REGEX = /^[a-zA-Z\s]+$/; // Regex to check for alphabets and spaces only
const PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/; // Password validation regex for allowed special characters

const uservalidation = (values) => {
  let errors = {};

  // Trim whitespace and normalize space in fields
  values.name = values.name ? values.name.trim().replace(/\s+/g, " ") : "";
  values.city = values.city ? values.city.trim() : "";
  values.userid = values.userid ? values.userid.trim() : "";
  values.phone = values.phone ? values.phone.trim() : "";
  values.pwd = values.pwd ? values.pwd.trim() : "";
  values.cpwd = values.cpwd ? values.cpwd.trim() : "";

  if (!values.name) {
    errors.name = "Name is required";
  } else if (!NAME_CITY_REGEX.test(values.name)) {
    errors.name = "Name can only include alphabets and spaces.";
  } else if (values.name.length < 3) {
    errors.name = "Are you sure you entered your name correctly?";
  } else if (values.name.length > 20) {
    errors.name = "Name must be 20 characters or fewer.";
  }

  if (!values.city) {
    errors.city = "City is required";
  } else if (!NAME_CITY_REGEX.test(values.city)) {
    errors.city = "City can only include alphabets.";
  } else if (values.city.length > 15) {
    errors.city = "City must be 15 characters or fewer.";
  }

  if (!values.userid) {
    errors.userid = "User ID is required";
  } else if (values.userid.length < 4) {
    errors.userid = "Enter a username with more than 4 characters.";
  } else if (values.userid.length > 10) {
    errors.userid = "Enter a username with 10 characters or fewer.";
  } else if (USER_ID_SPACE_REGEX.test(values.userid)) {
    errors.userid = "User ID cannot contain spaces.";
  } else if (!USER_ID_ALLOWED_CHARACTERS_REGEX.test(values.userid)) {
    errors.userid = "Only letters, numbers, underscores, and periods allowed.";
  } else if (
    !USER_ID_LETTER_REGEX.test(values.userid) ||
    !USER_ID_DIGIT_REGEX.test(values.userid)
  ) {
    errors.userid = "User ID must include at least one letter and one digit.";
  } else if (USER_ID_START_END_REGEX.test(values.userid)) {
    errors.userid = "User ID cannot start or end with a period or underscore.";
  } else if (USER_ID_START_END_REGEX.test(values.userid)) {
    errors.userid = "User ID cannot start or end with a period or underscore.";
  } else if (USER_ID_CONSECUTIVE_REGEX.test(values.userid)) {
    errors.userid = "You can't have more than one period in a row.";
  } else if (/^\d+$/.test(values.userid)) {
    errors.userid = "User ID cannot have all numbers.";
  } else if (/^\d/.test(values.userid)) {
    errors.userid = "User ID cannot start with a number.";
  }

  if (!values.phone) {
    errors.phone = "Phone number is required";
  } else if (!PHONE_REGEX.test(values.phone)) {
    errors.phone = "Phone number must be exactly 10 digits long";
  }

  if (!values.gender) {
    errors.gender = "Gender is required";
  }

  if (!values.pwd) {
    errors.pwd = "Password is required";
  } else {
    if (!PASSWORD_LENGTH_REGEX.test(values.pwd)) {
      errors.pwd = "Password must be between 8 and 15 characters long.";
    } else if (!PASSWORD_UPPERCASE_REGEX.test(values.pwd)) {
      errors.pwd = "Password must include at least one uppercase letter.";
    } else if (!PASSWORD_LOWERCASE_REGEX.test(values.pwd)) {
      errors.pwd = "Password must include at least one lowercase letter.";
    } else if (!PASSWORD_DIGIT_REGEX.test(values.pwd)) {
      errors.pwd = "Password must include at least one digit.";
    } else if (!PASSWORD_SPECIAL_REGEX.test(values.pwd)) {
      errors.pwd =
        "Password must include at least one special character (e.g., @$!%*?&).";
    } else if (!PASSWORD_REGEX.test(values.pwd)) {
      errors.pwd = "No special characters except @$!%*?&.";
    }
  }

  if (!values.cpwd) {
    errors.cpwd = "Confirm Password is required";
  } else if (values.pwd && values.cpwd && values.pwd !== values.cpwd) {
    errors.cpwd = "Passwords do not match";
  }

  return errors;
};

export default uservalidation;
