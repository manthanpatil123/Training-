const PRODUCT_NAME_REGEX = /^[a-zA-Z0-9\s]+$/; // Regex to allow alphabets, numbers, and spaces

const productvalidation = (values) => {
    let errors = {};

    // Normalize spaces in product name
    if (values.pname) {
        values.pname = values.pname
            .trim() // Remove leading and trailing white spaces
            .replace(/\s+/g, ' '); // Replace multiple spaces with a single space
    }

    // Validate product name
    if (!values.pname) {
        errors.pname = "Product Name is required";
    } else if (!PRODUCT_NAME_REGEX.test(values.pname)) {
        errors.pname = "Product Name can only include alphabets, numbers.";
    } else if (values.pname.length < 3) {
        errors.pname = "Product Name must be at least 3 characters long.";
    } else if (values.pname.length > 50) {
        errors.pname = "Product Name must be 50 characters or fewer.";
    }

    // Validate price
    if (!values.price) {
        errors.price = "Price is required";
    } else if (!/^\d+$/.test(values.price)) { // Ensure price is a whole number
        errors.price = "Price must be a positive whole number.";
    } else if (parseInt(values.price, 10) < 1) { // Ensure price is at least 1
        errors.price = "Price must be at least 1";
    } else if (values.price.length > 10) { // Ensure price field length is within a reasonable range
        errors.price = "Price must be 10 digits or fewer.";
    }

    // Validate quantity
    const qty = values.qty?.toString().trim(); // Convert to string and trim any extra spaces
    if (!qty) {
        errors.qty = "Quantity is required";
    } else if (!/^\d+$/.test(qty) || qty.includes('.')) { // Ensure quantity is a whole number and does not contain a decimal point
        errors.qty = "Quantity must be a positive whole number.";
    } else if (parseInt(qty, 10) < 1) { // Ensure quantity is at least 1
        errors.qty = "Quantity must be at least 1";
    } else if (parseInt(qty, 10) > 10000) { // Ensure quantity is within a reasonable range
        errors.qty = "Quantity cannot be more than 10,000";
    }

    // Validate category
    if (!values.pcat) {
        errors.pcat = "Category is required";
    } 

    // Validate photo
    if (!values.photo) {
        errors.photo = "Photo is required";
    }

    return errors;
};

export default productvalidation;
