const productvalidation = (values) => {
    let errors = {};

    // Normalize spaces in product name
    if (values.pname) {
        values.pname = values.pname
            .trim() // Remove leading and trailing white spaces
            .replace(/\s+/g, ' '); // Replace multiple spaces with a single space
    }

    if (!values.pname) {
        errors.pname = "Product Name is required";
    }

    if (!values.price) {
        errors.price = "Price is required";
    } else if (values.price < 1) {
        errors.price = "Price must be at least 1";
    }

    if (!values.qty) {
        errors.qty = "Quantity is required";
    } else if (values.qty < 1) {
        errors.qty = "Quantity must be at least 1";
    }

    if (!values.pcat) {
        errors.pcat = "Category is required";
    }

    if (!values.photo) {
        errors.photo = "Photo is required";
    }

    return errors;
};

export default productvalidation;
