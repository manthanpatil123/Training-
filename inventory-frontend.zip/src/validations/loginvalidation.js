const loginvalidation = (values) => {
    let errors = {};

    if (!values.userid) {
        errors.userid = "User ID is required";
    } else if (values.userid.length > 10) {
        errors.userid = "Enter a username with 10 characters or fewer.";
    }

    if (!values.pwd) {
        errors.pwd = "Password is required";
    } else if (values.pwd.length > 15) {
        errors.pwd = "Password cannot be more than 15 characters long.";
    }

    if (!values.role) {
        errors.role = "Role is required";
    }

    return errors;
}

export default loginvalidation;
