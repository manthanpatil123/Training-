// src/validations/cartValidation.js

export const validateCart = (cart) => {
    if (!Array.isArray(cart)) {
        console.error('Expected cart to be an array, but got:', cart);
        return {};
    }

    const errors = {};
    cart.forEach((item) => {
        
        if (!item.prodid) {
            errors[item.prodid] = 'Product ID is required';
        }
        
    });
    return errors;
};
