import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import NavBar from './components/NavBar';
import Header from './components/Header';
import { createContext, useState } from 'react';
import AllProduct from './pages/AllProducts';
import Login from './pages/Login';
import RegCustomer from './pages/RegCustomer';
import RegSupplier from './pages/RegSupplier';
import Categories from './pages/Categories';
import AllCustomers from './pages/AllCustomers';
import AllSellers from './pages/AllSellers';
import AddProduct from './pages/AddProduct';
import EditProduct from './pages/EditProduct';
import MyProducts from './pages/MyProducts';
import ProductDetails from './pages/ProductDetails';
import SellerProfile from './pages/SellerProfile';
import Orders from './pages/Orders';
import ViewCart from './pages/ViewCart';
import MyOrders from './pages/MyOrders';
import SellerOrders from './pages/SellerOrders';

export const GlobalInfo=createContext()

function App() {

  const [cats, setcats]=useState([])
  return (
    <div className="App">
      <GlobalInfo.Provider value={{ cats, setcats }}>
      <BrowserRouter>
      <Header />      
      <NavBar />
      <div className="container-fluid p-2">
      </div>
        <Routes>
          <Route element={<AllProduct />} path="/" exact />
          <Route element={<AllProduct />} path="/cats/:subcat" />
          <Route element={<SellerProfile />} path="/sprofile" />
          <Route element={<Login />} path="/login" />
          <Route element={<RegSupplier />} path="/regsupplier" />
          <Route element={<RegCustomer />} path="/register" />
          <Route element={<Categories />} path="/category" />  
          <Route element={<AllCustomers />} path="/customers" />          
          <Route element={<AllSellers />} path="/sellers" />
          <Route element={<AddProduct />} path="/add-product" />          
          <Route element={<EditProduct />} path="/edit/:prodid" />          
          <Route element={<MyProducts />} path="/myproducts" />   
          <Route element={<ProductDetails/>} path="/products/:prodid" />
          <Route element={<Orders />} path="/orders" />  
          <Route element={<MyOrders />} path="/myorders" />          
          <Route element={<SellerOrders />} path="/seller-orders" />          
          <Route element={<ViewCart />} path="/cart" />     
        </Routes>
      </BrowserRouter>
      </GlobalInfo.Provider>
    </div>
  );
}

export default App;
