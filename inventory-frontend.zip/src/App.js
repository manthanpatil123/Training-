import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NavBar from "./components/NavBar";
import Header from "./components/Header";
import { createContext, useState } from "react";
import LandingPage from "./pages/LandingPage"; // Import the new LandingPage component
import AllProduct from "./pages/AllProducts";
import Login from "./pages/Login";
import RegCustomer from "./pages/RegCustomer";
import RegSupplier from "./pages/RegSupplier";
import Categories from "./pages/Categories";
import AllCustomers from "./pages/AllCustomers";
import AllSellers from "./pages/AllSellers";
import AddProduct from "./pages/AddProduct";
import EditProduct from "./pages/EditProduct";
import MyProducts from "./pages/MyProducts";
import ProductDetails from "./pages/ProductDetails";
import SellerProfile from "./pages/SellerProfile";
import Orders from "./pages/Orders";
import ViewCart from "./pages/ViewCart";
import MyOrders from "./pages/MyOrders";
import SellerOrders from "./pages/SellerOrders";

export const GlobalInfo = createContext();

function App() {
  const [cats, setcats] = useState([]);
  return (
    <div className="App">
      <GlobalInfo.Provider value={{ cats, setcats }}>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route
              path="/home"
              element={
                <>
                  <Header />
                  <NavBar />
                  <AllProduct />
                </>
              }
            />
            <Route
              path="/cats/:subcat"
              element={
                <>
                  <Header />
                  <NavBar />
                  <AllProduct />
                </>
              }
            />
            <Route
              path="/sprofile"
              element={
                <>
                  <Header />
                  <NavBar />
                  <SellerProfile />
                </>
              }
            />
            <Route
              path="/login"
              element={
                <>
                  <Header />
                  <NavBar />
                  <Login />
                </>
              }
            />
            <Route
              path="/regsupplier"
              element={
                <>
                  <Header />
                  <NavBar />
                  <RegSupplier />
                </>
              }
            />
            <Route
              path="/register"
              element={
                <>
                  <Header />
                  <NavBar />
                  <RegCustomer />
                </>
              }
            />
            <Route
              path="/category"
              element={
                <>
                  <Header />
                  <NavBar />
                  <Categories />
                </>
              }
            />
            <Route
              path="/customers"
              element={
                <>
                  <Header />
                  <NavBar />
                  <AllCustomers />
                </>
              }
            />
            <Route
              path="/sellers"
              element={
                <>
                  <Header />
                  <NavBar />
                  <AllSellers />
                </>
              }
            />
            <Route
              path="/add-product"
              element={
                <>
                  <Header />
                  <NavBar />
                  <AddProduct />
                </>
              }
            />
            <Route
              path="/edit/:prodid"
              element={
                <>
                  <Header />
                  <NavBar />
                  <EditProduct />
                </>
              }
            />
            <Route
              path="/myproducts"
              element={
                <>
                  <Header />
                  <NavBar />
                  <MyProducts />
                </>
              }
            />
            <Route
              path="/products/:prodid"
              element={
                <>
                  <Header />
                  <NavBar />
                  <ProductDetails />
                </>
              }
            />
            <Route
              path="/orders"
              element={
                <>
                  <Header />
                  <NavBar />
                  <Orders />
                </>
              }
            />
            <Route
              path="/myorders"
              element={
                <>
                  <Header />
                  <NavBar />
                  <MyOrders />
                </>
              }
            />
            <Route
              path="/seller-orders"
              element={
                <>
                  <Header />
                  <NavBar />
                  <SellerOrders />
                </>
              }
            />
            <Route
              path="/cart"
              element={
                <>
                  <Header />
                  <NavBar />
                  <ViewCart />
                </>
              }
            />
          </Routes>
        </BrowserRouter>
      </GlobalInfo.Provider>
    </div>
  );
}

export default App;
