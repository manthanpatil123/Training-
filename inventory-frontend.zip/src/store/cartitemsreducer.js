import { CART_ACTIONS } from "./actions"

let initialState=[]

const cartitemsreducer=(state=initialState,action)=>{
    switch(action.type)
    {
        case CART_ACTIONS.LOAD_CART:
            state=action.payload
            return state
        case CART_ACTIONS.ADD_ITEM:                     
            return [...state,action.payload] 
        case CART_ACTIONS.REMOVE_ITEM:           
            return state.filter(x=>x.id!==action.payload)
        case CART_ACTIONS.CLEAR_CART:
            state=initialState
            return state
        default:
            return state
    }
}

export default cartitemsreducer;