import { CART_ACTIONS } from "./actions";

const initialState = [];

const cartitemsreducer = (state = initialState, action) => {
    switch (action.type) {
        case CART_ACTIONS.LOAD_CART:
            return action.payload;

        case CART_ACTIONS.ADD_ITEM:
            return [...state, action.payload];

        case CART_ACTIONS.REMOVE_ITEM:
            console.log('Removing item with ID:', action.payload);
            return state.filter(item => item.prodid !== action.payload);

        case CART_ACTIONS.CLEAR_CART:
            return initialState;

        default:
            return state;
    }
};

export default cartitemsreducer;
