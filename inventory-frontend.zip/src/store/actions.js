export const CART_ACTIONS= {
    LOAD_CART: "LoadCart",
    ADD_ITEM: "AddItem",
    REMOVE_ITEM: "RemoveItem",
    CLEAR_CART: "Clear"
};

export const LOGIN_ACTIONS ={
    IS_LOGGED_IN: "IsLoggedIn",
    LOGOUT: "LogOut"
}