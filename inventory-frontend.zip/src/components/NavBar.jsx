import { useSelector } from "react-redux";
import { Link, NavLink } from "react-router-dom";
import RoleNavbar from "./RoleNavbar";
import { useContext } from "react";
import { useEffect } from "react";
import axios from "axios";
import { GlobalInfo } from "../App";
import { BASE_URL } from "../constants/constants";

function NavBar(){
    const state=useSelector((state)=>state); 
    const {cats,setcats}=useContext(GlobalInfo)  
    const isLoggedIn = state.loggedin.IsLoggedIn;
    const role = state.loggedin.Role;   

    useEffect(()=>{
        axios.get(BASE_URL+'api/category')
        .then(resp=> setcats(resp.data))
        .catch(setcats([]));   
    },[])

    return (
        <>
            <div className="clearfix"></div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light position-sticky mb-0" style={{top:0,zIndex:"1000"}}>
                <Link className="navbar-brand" to="/">E-Shop</Link>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul className="navbar-nav">
                    <li className="nav-item active">
                        <NavLink className="nav-link" to="/">Home</NavLink>
                    </li>
                        <li className="nav-item dropdown">
                        <Link className="nav-link dropdown-toggle" to="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Categories
                        </Link>
                            <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            {cats && cats.map(x=>(
                                    <Link key={x.catid} className="dropdown-item" to={'/cats/'+x.catid}>{x.catname}</Link>
                                ))}                                                      
                            </div>
                        </li>
                    </ul>
                    <RoleNavbar isLoggedIn={isLoggedIn} />                    
                    
                </div>
                </nav>
        </>
    )
}

export default NavBar;
