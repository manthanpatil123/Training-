import { useDispatch, useSelector } from "react-redux";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { Menus } from "./Menus";
import { useEffect, useState } from "react";
import { CART_ACTIONS, LOGIN_ACTIONS } from "../store/actions";

const RoleNavbar = ({ isLoggedIn }) => {
  const navigate = useNavigate();
  const [signout,setsignout]=useState(false)

  const logout = () => {
    setsignout(Math.random())
  };

  const state = useSelector((state) => state);
  const dispatch = useDispatch();
  const cartqty=state.cart && state.cart.length>0 ? state.cart.map(c=>c.qty).reduce((a,b)=>parseInt(a)+parseInt(b)) :null;
  const role = isLoggedIn ? localStorage.getItem("role") : "guest";
  
  useEffect(()=>{
    dispatch({ type: LOGIN_ACTIONS.LOGOUT });
    dispatch({type: CART_ACTIONS.CLEAR_CART});    
    localStorage.clear();
    navigate('/',{ replace: true });
  },[signout])
  
  return (
    <ul className="navbar-nav ml-auto">
      {Menus.filter((x) => x.role.includes(role)).map((x) =>
        x.children ? (
            <li key={x.name} className="nav-item dropdown">
              <Link
                className="nav-link dropdown-toggle"
                to="#"
                id="navbarDropdownMenuLink"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                {x.name}
              </Link>
              <div
                className="dropdown-menu"
                aria-labelledby="navbarDropdownMenuLink"
              >
              {x.children.map(s=>(            
                <Link key={s.name} className="dropdown-item" to={s.route}>
                  {s.name}
                </Link>
              ))}
              </div>
            </li>
          )
         : (
            x.name==="View Cart" ? (
                <li key={x.name} className="nav-item">
                <NavLink className="nav-link" to={x.route}>{x.name}
                {state.cart.length===0 ? null :
                <span className="badge badge-primary p-2 ml-1">
                    {cartqty}
                </span>}
                </NavLink>
                </li>    
            ):(
            <li key={x.name} className="nav-item">
               <NavLink className="nav-link" to={x.route}>{x.name}</NavLink>
            </li>)
         )
         )}
        {role !== "guest" ? (
        <li className="nav-item">
            <Link className="nav-link" onClick={e=>logout()} to="#">
            Logout
            </Link>
        </li>            
        ):null}
    </ul>
  );
};

export default RoleNavbar;
