import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../constants/constants";
import "../CSS/Home.css"; // Assuming your global CSS is imported here

function Product(props) {
  const { x } = props;
  const navigate = useNavigate();

  return (
    <div className="col-lg-3 col-md-4 col-sm-6 " key={x.prodid}>
      <div className="product-card-clean">
        <div className="product-card-clean">
          <div
            className="card-clean"
            onClick={() => navigate("/products/" + x.prodid)}
          >
            <img
              alt="Product"
              src={BASE_URL + "images/" + x.photo}
              className="product-image-clean"
            />
            <div className="card-content-clean">
              <h5>{x.pname}</h5>
              <p className="category-name">{x.category.catname}</p>
              <div className="price-clean">
                &#8377; {new Intl.NumberFormat("en-IN").format(x.price)}
              </div>
              <button className="btn btn-dark">Buy Now</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Product;
