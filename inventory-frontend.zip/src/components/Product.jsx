import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../constants/constants";

function Product(props) {
  const { x } = props;
  const navigate = useNavigate();

  return (
    <div
      className="col-sm-3"
      style={{ cursor: "pointer" }}
      role="button"
      key={x.prodid}
      onClick={() => navigate("/products/" + x.prodid)}
    >
      <div
        className="card text-center mb-3 bg-transparent"
        style={{ boxShadow: "0 0 3px 3px white" }}
      >
        <div className="card-header p-1 border-bottom border-white">
          <h5>{x.pname}</h5>
        </div>
        <div className="card-body py-1">
          <img
            alt="Product"
            style={{ width: "90%", height: "250px", marginBottom: "10px" }}
            src={BASE_URL + 'images/' + x.photo}
            className="img-thumbnail"
          />
          <h6 className="float-left">{x.category.catname}</h6>
          <h6 className="float-right">
            Price: &#8377; {new Intl.NumberFormat('en-IN').format(x.price)}
          </h6>
        </div>
      </div>
    </div>
  );
}

export default Product;
