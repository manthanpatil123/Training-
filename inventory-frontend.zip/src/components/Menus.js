export const Menus=[
    {
        name: "Home",
        route: "/",
        role: [""]
    },
    {
        name: "Login",
        route: "/login",
        role: ["guest"]
    },
    {
        name: "Register",
        route: "/register",
        role: ["guest"],
        children: [
            {name: "Seller",
            route: "/regsupplier"},
            {name: "Customer",
            route: "/register"},
        ]
    },
    {
        name: "View Cart",
        route: "/cart",
        role: ["Customer"]
    },
    {
        name: "My Orders",
        route: "/myorders",
        role: ["Customer"]
    },
    
    {
        name: "Profile",
        route: "/sprofile",
        role: ["Seller"]
    },
    {
        name: "Add Product",
        route: "/add-product",
        role: ["Seller"]
    },
    {
        name: "Orders",
        route: "/seller-orders",
        role: ["Seller"]
    },
    {
        name: "Products",
        route: "/myproducts",
        role: ["Seller"]
    },
    {
        name: "Category",
        route: "/category",
        role: ["Admin"]
    },
    {
        name: "Sellers",
        route: "/Sellers",
        role: ["Admin"]
    },
    {
        name: "Customers",
        route: "/Customers",
        role: ["Admin"]
    },
    {
        name: "Orders",
        route: "/orders",
        role: ["Admin"]
    },
    
];